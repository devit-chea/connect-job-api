import os
from pathlib import Path
from environs import Env

DEBUG = True

BASE_DIR = Path(__file__).resolve().parent.parent.parent
env = Env()
env.read_env()

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": os.path.join(BASE_DIR, "db.sqlite3"),
    }
}

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

AUTH_PASSWORD_VALIDATORS = [{"NAME": "testapp.validators.Is666"}]

SECRET_KEY = "_"

MIDDLEWARE = ["django.contrib.sessions.middleware.SessionMiddleware"]


INSTALLED_APPS = (
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.staticfiles",
    "rest_framework",
    "drf_spectacular",
    "wdg_storage.file_metadata",
)

STATIC_URL = "/static/"

REST_FRAMEWORK = {
    "DEFAULT_PERMISSION_CLASSES": ("rest_framework.permissions.IsAuthenticated",),
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework.authentication.TokenAuthentication",
    ),
    'DEFAULT_SCHEMA_CLASS': 'drf_spectacular.openapi.AutoSchema',
}

ROOT_URLCONF = "configs.urls"

TEMPLATES = [
    {"BACKEND": "django.template.backends.django.DjangoTemplates", "APP_DIRS": True}
]

AUTHENTICATION_BACKENDS = [
    "django.contrib.auth.backends.ModelBackend",
    "djoser.social.backends.facebook.FacebookOAuth2Override",
    "social_core.backends.google.GoogleOAuth2",
    "social_core.backends.steam.SteamOpenId",
]

SPECTACULAR_SETTINGS = {
    "TITLE": "Swagger",
    "DESCRIPTION": "Swagger API",
    "VERSION": "1.0.0",
    "SCHEMA_PATH_PREFIX": "/api",
    "SERVE_INCLUDE_SCHEMA": False,
    "SWAGGER_UI_SETTINGS": """{
        deepLinking: true,
        filter: true,
        presets: [
            SwaggerUIBundle.presets.apis, 
            SwaggerUIStandalonePreset
        ],
        layout: "StandaloneLayout",
    }""",
}

SIMPLE_JWT = {}

# # S3 by PowerScale
AWS_S3_ACCESS_KEY_ID = env.str("AWS_S3_ACCESS_KEY_ID", None)
AWS_S3_SECRET_ACCESS_KEY = env.str("AWS_S3_SECRET_ACCESS_KEY", None)
S3_STORAGE_BUCKET_NAME = env.str("S3_STORAGE_BUCKET_NAME", None)
AWS_S3_ENDPOINT_URL = env.str("AWS_S3_ENDPOINT_URL", None)
AWS_STORAGE_BUCKET_NAME = env.str("AWS_STORAGE_BUCKET_NAME", None)
AWS_S3_REGION_NAME = None
AWS_S3_PRESIGN_EXPIRE = env.int("AWS_S3_PRESIGN_EXPIRE", 3600)
S3_PROTOCOL = env.str("S3_PROTOCOL", "https")

WDG_STORAGE_PATH="job-platform"
WDG_STORAGE_SAVE_METADATA=True
WDG_STORAGE_PROXY_URL="dev.wingdigital.com:3000/s3"
WDG_STORAGE_MAX_FILE_SIZE = env.int("WDG_STORAGE_MAX_FILE_SIZE", 5 * 1024 * 1024)
WDG_STORAGE_ALLOWED_EXTENSIONS = env.json("WDG_STORAGE_ALLOWED_EXTENSIONS", None)