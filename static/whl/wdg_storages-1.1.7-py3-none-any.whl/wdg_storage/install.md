# WDG Storages – Installation & Usage Guide

`wdg-storages` is a Django helper package for integrating **S3-compatible file storage**.  
It simplifies working with file metadata, presigned URLs, and file lifecycle operations.

The package provides utilities for:

- File metadata management
- Presigned URL generation
- File retrieval
- Upload status updates
- Soft delete and restore

It works with **AWS S3 or any S3-compatible storage service** (MinIO, DigitalOcean Spaces, etc).

---

# 1. Installation

Install the latest version from **PyPI**:

```bash
pip install wdg-storages
```

Or specify a version in your `requirements.txt`:

```
wdg-storages==1.0.2
```

Then install all requirements with:

```bash
pip install -r requirements.txt
```
```

# 2. Dependencies

The package installs these dependencies automatically:

- Django >= 4.2
- boto3
- django-storages
- environs
- httpx

---

# 3. Django Configuration

Add the storage dependency to your Django project:

```python
INSTALLED_APPS = [
    'wdg_storage.file_metadata',
]

```
Then run migrations:

```bash
python manage.py migrate
```
---


---
# 4. Configure `urls.py`,

```python 
urlpatterns = [
    (...),
    path("", include("wdg_storage.urls")),
]
```
---

# 5. Environment Configuration

Configure your **S3 credentials and storage settings** using environment variables.

Example `.env`:

```env
AWS_S3_ACCESS_KEY_ID=your-access-key
AWS_S3_SECRET_ACCESS_KEY=your-secret-key

AWS_STORAGE_BUCKET_NAME=your-bucket-name
AWS_S3_REGION_NAME=ap-southeast-1

AWS_S3_ENDPOINT_URL=

AWS_S3_PRESIGN_EXPIRE=3600
WDG_STORAGE_PROXY_URL=
```

## Variable Explanation

| Variable | Description |
|----------|-------------|
| `AWS_S3_ACCESS_KEY_ID` | Access key used to authenticate with the S3 service. |
| `AWS_S3_SECRET_ACCESS_KEY` | Secret key associated with the access key. |
| `AWS_STORAGE_BUCKET_NAME` | Name of the S3 bucket where files are stored. |
| `AWS_S3_REGION_NAME` | AWS region where the bucket is located (e.g., `ap-southeast-1`). |
| `AWS_S3_ENDPOINT_URL` | Optional custom endpoint for S3-compatible services such as **MinIO**, **DigitalOcean Spaces**, or **Cloudflare R2**. |
| `AWS_S3_PRESIGN_EXPIRE` | Expiration time (in seconds) for generated presigned URLs. |
| `WDG_STORAGE_PROXY_URL` | Optional proxy URL used to route file requests through a storage proxy service. |

---

# 6. Basic Usage

The package provides **three usage styles**:

1. Service Class
2. Mixin
3. Function helpers

---

# 7. Service Class Usage

Import the service:

```python
from wdg_storage.base import WdgStorageService
```

---

## Get File Metadata + URL

```python
files = WdgStorageService.get_files(file_id="A123")
```

Example response:

```python
[
  {
    "file_id": "A123",
    "original_filename": "invoice.pdf",
    "mime_type": "application/pdf",
    "file_size": 10240,
    "url": "https://presigned-url...",
    ...
  }
]
```

By default, **deleted files are excluded** from the results.

---

## Include Deleted Files

If you want to include **soft-deleted files** in the response, pass the argument `include_deleted=True`.

```python
files = WdgStorageService.get_files(
    file_id="A123",
    include_deleted=True
)
```

This will return both **active and soft-deleted files**.

---

## Get Multiple Files

```python
files = WdgStorageService.get_files(
    file_id=["A123", "B456"]
)
```

---

## Get Files by Instance

Retrieve all files attached to a model instance.

```python
files = WdgStorageService.get_files(instance=order)
```

You can also include deleted files:

```python
files = WdgStorageService.get_files(
    instance=order,
    include_deleted=True
)
```

---

## Download Files (URL Only)

```python
urls = WdgStorageService.download_files(
    file_id=["A123", "B456"]
)
```

Example response:

```python
[
  {"file_id": "A123", "url": "https://..."},
  {"file_id": "B456", "url": "https://..."}
]
```

---

## Get Single File URL

```python
url = WdgStorageService.get_file_url(file_id="A123")
```

Returns the presigned URL of the **first matched file**.

# 8. Update Upload Metadata

After a file upload is completed, update its status.

```python
WdgStorageService.update_metadata(
    file_id="A123",
    instance=order,
    is_success=True
)
```

Example use case:

1. Client uploads file to S3
2. Backend confirms upload success
3. Backend updates metadata

---

# 9. Delete Files

### Soft delete

```python
WdgStorageService.delete_files(
    file_id="A123",
    soft=True
)
```

### Hard delete

```python
WdgStorageService.delete_files(
    file_id="A123"
)
```

---

# 10. Restore Files

```python
WdgStorageService.restore_files(
    file_id="A123"
)
```

---

# 11. Using `files_data` Format

For advanced integrations, you can pass structured input.

```python
files = WdgStorageService.get_files(
    files_data=[
        {"file_id": "A123", "instance": order},
        {"file_id": "B456", "instance": order},
    ]
)
```

---

# 12. Function Shortcuts

You may also use helper functions.

```python
from wdg_storage.base import (
    get_files,
    download_files,
    get_file_url,
    update_metadata,
)
```

Example:

```python
files = get_files("A123")

urls = download_files(["A123", "B456"])

url = get_file_url("A123")
```

---

# 13. Using the Mixin

The mixin is useful in **Django REST Framework serializers or views**.

```python
from wdg_storage.base import WdgStorageMixin
```

Example serializer:

```python
from rest_framework import serializers
from wdg_storage.base import WdgStorageMixin


class OrderSerializer(WdgStorageMixin, serializers.Serializer):

    def validate(self, data):
        files = self.get_files(file_id=data["file_id"])
        return data
```

---

# 14. Supported Input Formats

The API accepts multiple formats.

### Single file

```python
get_files(file_id="A123")
```

### Multiple files

```python
get_files(file_id=["A123", "B456"])
```

### With instance

```python
get_files(file_id="A123", instance=order)
```

### Instance only

```python
get_files(instance=order)
```

### Structured format

```python
get_files([
  {"file_id": "A123", "instance": order}
])
```

---

# 15. Supported Python Versions

- Python 3.9
- Python 3.10
- Python 3.11
- Python 3.12

---

# 16. Supported Django Versions

- Django 4.2 (LTS)
- Django 5.x

---

# 17. Example Workflow

Typical upload workflow:

1. Client requests upload permission
2. Client uploads file to S3
3. Backend updates metadata
4. Application retrieves file later using presigned URL

Example:

```python
WdgStorageService.update_metadata(
    file_id="FILE123",
    instance=order,
    is_success=True
)

files = WdgStorageService.get_files(instance=order)
```

---

# 18. License

MIT License