import uuid
import mimetypes
from django.conf import settings
from django.db import models
from django.db.models import Sum, Count
from django.utils.translation import gettext_lazy as _
from wdg_storage.constant import UploadStatus, ProviderChoices, AccessLevelChoices

abstract = "wdg_storage.file_metadata" not in settings.INSTALLED_APPS


class WdgStorageModel(models.Model):
    """
    A general-purpose file storage model for S3 or other storage providers.
    Handles file metadata, access control, and reference mapping.
    """

    # === Core File Metadata ===
    file_id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
        help_text=_("Unique file identifier (UUID)."),
    )
    original_filename = models.CharField(
        max_length=255, help_text=_("Original name of the uploaded file.")
    )
    stored_filename = models.CharField(
        max_length=250, help_text=_("Name of the file stored in the storage provider.")
    )
    mime_type = models.CharField(
        max_length=255, help_text=_("Detected or provided MIME type of the file.")
    )
    file_size_bytes = models.PositiveBigIntegerField(help_text=_("File size in bytes."))
    checksum = models.CharField(
        max_length=255,
        blank=True,
        help_text=_("Checksum or hash (MD5/SHA) for integrity verification."),
    )

    # === Storage Information ===
    storage_path = models.TextField(
        max_length=1024, help_text=_("Full path or key within the storage provider.")
    )
    storage_provider = models.CharField(
        max_length=50,
        choices=ProviderChoices.choices,
        default=ProviderChoices.AWS_S3,
    )
    status = models.CharField(
        max_length=64,
        blank=True,
        default=UploadStatus.PENDING,
        choices=UploadStatus.CHOICES,
        help_text=_("Current upload lifecycle status."),
    )
    deleted = models.BooleanField(
        default=False, help_text=_("Indicates whether the file is soft-deleted.")
    )

    # === Access Control ===
    access_level = models.CharField(
        max_length=52,
        choices=AccessLevelChoices.choices,
        default=AccessLevelChoices.PRIVATE,
        help_text=_("Determines whether the file is public or private."),
    )

    # === External References ===
    ref_id = models.CharField(
        max_length=100,
        blank=True,
        db_comment="Object ID from external/intify service",
    )
    ref_type = models.CharField(
        max_length=100,
        blank=True,
        db_comment="Model content type",
    )
    ref_field = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        default="",
        db_comment="Field name associated with the reference relation",
    )
    description = models.CharField(max_length=255, blank=True)
    # === Audit Fields ===
    create_date = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    write_date = models.DateTimeField(auto_now=True, blank=True, null=True)
    create_uid = models.CharField(max_length=255, blank=True)
    write_uid = models.CharField(max_length=255, blank=True)

    # ==========================
    # QUERYSET / MANAGER
    # ==========================

    class StorageQuerySet(models.QuerySet):
        # ---- Basic Filters ----
        def active(self):
            """Return non-deleted files."""
            return self.filter(deleted=False)

        def deleted(self):
            """Return soft-deleted files."""
            return self.filter(deleted=True)

        def uploaded(self):
            """Return successfully uploaded files."""
            return self.filter(status=UploadStatus.COMPLETED)

        def pending(self):
            """Return files that are pending upload."""
            return self.filter(status=UploadStatus.PENDING)

        def failed(self):
            """Return failed uploads."""
            return self.filter(status=UploadStatus.FAILED)

        # ---- Access Level Filters ----
        def public(self):
            return self.filter(access_level=AccessLevelChoices.PUBLIC)

        def private(self):
            return self.filter(access_level=AccessLevelChoices.PRIVATE)

        # ---- PK, Provider & Reference ----
        def by_provider(self, provider: str):
            return self.filter(storage_provider=provider)

        def by_pk(self, pk: str):
            return self.filter(pk=pk)

        def by_reference(self, ref_id: str, ref_type: str = None):
            qs = self.filter(ref_id=ref_id)
            if ref_type:
                qs = qs.filter(ref_type=ref_type)
            return qs

        # ---- File Searching ----
        def search(self, keyword: str):
            return self.filter(original_filename__icontains=keyword)

        # ---- Aggregations ----
        def summarize_by_provider(self):
            return self.values("storage_provider").annotate(
                total_files=Count("file_id"),
                total_size=Sum("file_size_bytes"),
            )

        def summarize_by_access_level(self):
            return self.values("access_level").annotate(
                total_files=Count("file_id"),
                total_size=Sum("file_size_bytes"),
            )

    # Attach custom manager
    objects = StorageQuerySet.as_manager()

    # ==========================
    # META
    # ==========================
    class Meta:
        db_table = "wdg_storage"
        abstract = abstract
        verbose_name = _("WDG File Storage")
        verbose_name_plural = _("WDG File Storages")
        indexes = [
            models.Index(fields=["storage_provider"]),
            models.Index(fields=["status"]),
            models.Index(fields=["ref_id", "ref_type"]),
            models.Index(fields=["access_level"]),
        ]

    def save(self, *args, **kwargs):
        if self.ref_id == None:
            self.ref_id = ""

        if self.ref_type == None:
            self.ref_type = ""

        if self.ref_field == None:
            self.ref_field = ""
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.original_filename} ({self.mime_type})"

    # === Utility Methods ===

    @property
    def is_uploaded(self) -> bool:
        """Return True if file upload completed successfully."""
        return self.status == UploadStatus.COMPLETED

    @property
    def file_size(self):
        """Return a file size."""
        return round(self.file_size_bytes / (1024 * 1024), 2)

    @property
    def human_size(self) -> str:
        """Return a human-readable file size."""
        size = self.file_size_bytes
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size < 1024.0:
                return f"{size:.2f} {unit}"
            size /= 1024.0
        return f"{size:.2f} PB"

    @classmethod
    def guess_mime_type(cls, filename: str) -> str:
        """Guess MIME type based on filename extension."""
        mime_type, _ = mimetypes.guess_type(filename)
        return mime_type or "application/octet-stream"

    def soft_delete(self, user_id: int | None = None):
        """Mark file as deleted (soft delete)."""
        self.deleted = True
        self.write_uid = user_id
        self.save(update_fields=["deleted", "write_uid", "write_date"])

    def restore(self, user_id: int | None = None):
        """Restore a soft-deleted file."""
        self.deleted = False
        self.write_uid = user_id
        self.save(update_fields=["deleted", "write_uid", "write_date"])

    def mark_uploaded(self):
        """Mark upload as successful."""
        self.status = UploadStatus.COMPLETED
        self.save(update_fields=["status", "write_date"])
