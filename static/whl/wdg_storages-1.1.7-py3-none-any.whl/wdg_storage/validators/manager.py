from rest_framework import serializers


class FileValidationManager:
    """Manages and executes multiple validators on uploaded files."""

    def __init__(self, validators):
        """
        validators: list of validator instances
        Example:
            [ExtensionValidator(...), SizeValidator(...)]
        """
        self.validators = validators

    def validate(self, file):
        """Run all validators on a single file."""
        for validator in self.validators:
            validator.validate(file)

    def validate_many(self, files):
        """Validate a list of files."""
        errors = []
        for file in files:
            try:
                self.validate(file)
            except serializers.ValidationError as e:
                if isinstance(e.detail, list):
                    errors.extend(e.detail)
                else:
                    errors.append(e.detail)

        if errors:
            raise serializers.ValidationError(errors)
