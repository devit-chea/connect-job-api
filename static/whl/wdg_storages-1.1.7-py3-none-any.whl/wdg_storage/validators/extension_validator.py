import os
from rest_framework import serializers
from wdg_storage.validators.base import BaseFileValidator


class ExtensionValidator(BaseFileValidator):
    """Validate allowed file extensions."""

    def validate(self, file):
        allowed_extensions = self.options.get("allowed_extensions", [])
        # Handle both UploadedFile and bytes cases
        filename = getattr(file, "name", None)

        if not filename and isinstance(file, bytes):
            raise serializers.ValidationError(
                "Invalid file object received. Expected a file upload."
            )

        ext = os.path.splitext(filename)[1][1:].lower() if filename else ""

        if allowed_extensions and ext not in allowed_extensions:
            allowed_str = ", ".join(allowed_extensions)

            raise serializers.ValidationError(
                f"Extension '{ext}' is not allowed. "
                f"Allowed extensions are: '{allowed_str}'."
            )
