import re
import os
import logging
import mimetypes
from typing import Any, List, Optional
from django.db.models import Q
from django.conf import settings
from botocore.exceptions import ClientError
from django.db.models import Model, QuerySet
from django.core.exceptions import ImproperlyConfigured
from django.contrib.contenttypes.models import ContentType

from wdg_storage.backends.s3_client import S3Storage
from wdg_storage.backends.file_system import FileSystem

from wdg_storage.file_metadata.models.storage_model import WdgStorageModel
from wdg_storage.constant import (
    UploadStatus,
    EngineChoices,
    ProviderChoices,
    ResponseTypeChoices,
)
from wdg_storage.utils.commons import (
    add_slash,
    get_cached_url,
    unique_file_name,
    compute_checksums,
    build_storage_path,
    build_local_storage_path,
)
from django.db import transaction

from urllib.parse import urlparse, parse_qs
from datetime import datetime, timezone as dt_timezone
from django.utils import timezone as dj_timezone

logger = logging.getLogger(__name__)

# --------------------------------------------------------
# CONSTANTS
# --------------------------------------------------------
NO_FILES_FOUND = "No files found."
_RAW_S3_BUCKET_PATH = getattr(settings, "WDG_STORAGE_PATH", "")
_WDG_STORAGE_PROXY_URL = getattr(settings, "WDG_STORAGE_PROXY_URL", "")
_AWS_S3_PRESIGN_EXPIRE = getattr(settings, "AWS_S3_PRESIGN_EXPIRE", 3600)


def update_file_record(
    file_id,
    instance=None,
    ref_id=None,
    ref_type=None,
    ref_field=None,
    is_success=None,
):
    """
    Low-level function to update a single WdgStorageModel record.

    Args:
        file_id (str):
            File ID to update.

        instance (Model, optional):
            Django model instance used to resolve:
                - ref_id
                - ref_type

        ref_id (str | int, optional):
            Explicit reference object ID.

        ref_type (str, optional):
            Explicit reference model/type name.

        ref_field (str, optional):
            Logical field/group associated with the file.

        is_success (bool, optional):
            Upload result status.
            - True  -> completed
            - False -> failed

    Returns:
        int: Number of updated records (0 if instance invalid or nothing to update).
    """

    success = bool(is_success)
    status = UploadStatus.COMPLETED if success else UploadStatus.FAILED

    resolved_ref_id = None
    resolved_ref_type = None

    write_uid = None
    create_uid = None

    # Priority 1: instance
    if isinstance(instance, Model):

        resolved_ref_id = instance.pk
        resolved_ref_type = instance._meta.model_name

        write_uid = getattr(instance, "write_uid", None)
        create_uid = getattr(instance, "create_uid", None)

    # Priority 2: explicit refs
    elif ref_id is not None and ref_type:

        resolved_ref_id = ref_id
        resolved_ref_type = ref_type

    else:
        return 0

    with transaction.atomic():
        try:
            obj = WdgStorageModel.objects.select_for_update().get(
                Q(ref_id="") | Q(ref_id__isnull=True),
                Q(ref_type="") | Q(ref_type__isnull=True),
                file_id=file_id,
            )
        except WdgStorageModel.DoesNotExist:
            return 0

        # Update DB reference
        obj.status = status
        obj.ref_id = resolved_ref_id
        obj.ref_type = resolved_ref_type
        obj.ref_field = ref_field or ""
        if write_uid is not None:
            obj.write_uid = write_uid
        if create_uid is not None:
            obj.create_uid = create_uid

        new_key = build_storage_path(
            filename=obj.stored_filename,
            instance=instance,
            ref_type=ref_type,
            is_temp=False,
        )

        if obj.storage_path != new_key:
            s3 = S3Storage()
            # Move object (COPY + DELETE)
            s3.move_object(
                source_key=obj.storage_path,
                dest_key=new_key,
            )
            obj.storage_path = new_key

        obj.save()

    return 1


def extract_ref_from_instance(instance: Model):
    if not isinstance(instance, Model):
        return None, None
    content_type = ContentType.objects.get_for_model(instance.__class__)
    return content_type.model, instance.pk


def apply_reference(instance, f: WdgStorageModel):
    if not isinstance(instance, Model):
        return
    ref_type, ref_id = extract_ref_from_instance(instance)
    f.ref_type = ref_type
    f.ref_id = ref_id

    if hasattr(instance, "write_uid"):
        f.write_uid = getattr(instance, "write_uid", "") or ""
    if hasattr(instance, "create_uid"):
        f.create_uid = getattr(instance, "create_uid", "") or ""


class FileSystemService:
    """
    Local filesystem storage service.

    Files are stored inside integrator project directory.

    Example:
        <PROJECT_ROOT>/storages/tenant_1/2026/common/file.pdf
    """

    @staticmethod
    def _get_local_engine():
        return FileSystem()

    @staticmethod
    def save_filesystem(
        *,
        file=None,
        file_bytes: bytes | None = None,
        filename: str | None = None,
        instance: Model,
        mime_type: str = "application/octet-stream",
        ref_field: str = "",
        **kwargs,
    ) -> dict[str, Any]:
        """
        Save file into local filesystem.

        Supports:
        - UploadedFile
        - bytes
        - BytesIO export
        - generated files

        Examples:
            save_filesystem(file=request.FILES["file"])

            save_filesystem(
                file_bytes=output.getvalue(),
                filename="export.xlsx",
            )
        """

        local_engine = FileSystemService._get_local_engine()

        is_url = kwargs.get(
            "is_url",
            False,
        )
        # UPLOADED FILE
        # =====================================================

        if file is not None:

            file_content = file.read()

            original_name = file.name

            mime = getattr(
                file,
                "content_type",
                mime_type,
            )

        elif file_bytes is not None:

            file_content = file_bytes

            if not filename:

                raise ValueError("filename is required when using file_bytes")

            original_name = filename

            mime = mime_type

        else:

            raise ValueError("Either file or file_bytes must be provided.")

        size = len(file_content)
        sha256, _ = compute_checksums(file_content)
        stored_name = unique_file_name(original_name)

        # STORAGE PATH
        key = build_local_storage_path(filename=stored_name, instance=instance)

        # SAVE FILE

        result = local_engine.upload_fileobj(key=key, file_bytes=file_content)

        if not result.get("success"):

            raise RuntimeError(result.get("error"))

        obj = WdgStorageModel.objects.create(
            original_filename=original_name,
            stored_filename=stored_name,
            mime_type=mime,
            file_size_bytes=size,
            checksum=sha256,
            storage_path=f"storages/{key}",
            ref_field=ref_field,
            status=UploadStatus.COMPLETED,
            storage_provider=ProviderChoices.LOCAL_FILESYSTEM,
        )

        apply_reference(
            instance,
            obj,
        )

        obj.save()

        response = {
            "file_id": str(obj.file_id),
            "ref_field": obj.ref_field,
            "file_url": obj.storage_path,
            "original_name": original_name,
            "human_size": obj.human_size,
            "file_size": obj.file_size,
            "create_date": obj.create_date,
            "storage_provider": obj.storage_provider,
        }

        if is_url:
            response["url"] = FileSystemService.get_url(obj)

        return response

    @staticmethod
    def get_url(
        obj: WdgStorageModel,
    ) -> str:
        """
        Get direct URL from storage object.
        """

        local_engine = FileSystemService._get_local_engine()

        return local_engine.get_url(obj.storage_path)

    @staticmethod
    def get_url_by_reference(
        instance: Model,
        ref_field: str = "",
    ) -> str | None:
        """
        Get latest file URL by instance reference.
        """

        ref_type, ref_id = extract_ref_from_instance(instance)

        obj = (
            WdgStorageModel.objects.filter(
                ref_type=ref_type,
                ref_id=ref_id,
                ref_field=ref_field,
                storage_provider=ProviderChoices.LOCAL_FILESYSTEM,
            )
            .order_by("-create_date")
            .first()
        )

        if not obj:
            return None

        return FileSystemService.get_url(obj)

    @staticmethod
    def get_obj_by_reference(
        instance: Model,
        ref_field: str = "",
        storage_provider: str = ProviderChoices.LOCAL_FILESYSTEM,
    ) -> WdgStorageModel | None:
        """
        Get latest storage object by instance reference.
        """

        ref_type, ref_id = extract_ref_from_instance(instance)

        return (
            WdgStorageModel.objects.filter(
                ref_type=ref_type,
                ref_id=ref_id,
                ref_field=ref_field,
                storage_provider=storage_provider,
            )
            .order_by("-create_date")
            .first()
        )

    @staticmethod
    def delete_file(key: str) -> bool:
        """
        Delete direct URL from storage object.

        key: storage_path
        """

        local_engine = FileSystemService._get_local_engine()

        return local_engine.delete_file(key)

    @staticmethod
    def delete_file_by_reference(
        instance: Model,
        ref_field: str = "",
    ) -> int:
        """
        Delete all files by instance reference.

        Returns:
            int: Number of deleted files
        """

        ref_type, ref_id = extract_ref_from_instance(instance)

        queryset = WdgStorageModel.objects.filter(
            ref_type=ref_type,
            ref_id=ref_id,
            ref_field=ref_field,
            storage_provider=ProviderChoices.LOCAL_FILESYSTEM,
        )

        deleted_count = 0

        for obj in queryset.iterator():

            FileSystemService.delete_file(obj.storage_path)
            obj.delete()

            deleted_count += 1

        return deleted_count


class FileStorageService:
    """
    File storage service using S3-compatible storage.

    Supports:
    - AWS S3
    - MinIO
    - Dell PowerScale
    """

    # -------------------------
    # Internal helpers
    # -------------------------
    @staticmethod
    def _sanitize_s3_path(value: str) -> str:
        if not value or not isinstance(value, str):
            raise ImproperlyConfigured(
                "Environment variable WDG_STORAGE_PATH must be a non-empty string."
            )
        value = value.replace("\\", "/")
        value = value.lstrip("/")
        value = re.sub(r"/+", "/", value)
        if not value.endswith("/"):
            value += "/"
        return value

    @staticmethod
    def _ensure_list(value):
        if not value:
            return []
        if isinstance(value, list):
            return value
        return [value]

    @staticmethod
    def _key(stored_name: str) -> str:
        base = add_slash(FileStorageService._sanitize_s3_path(_RAW_S3_BUCKET_PATH))
        return f"{base}{stored_name}"

    @staticmethod
    def _extract_file_bytes(uploaded) -> bytes:
        """
        Accept either raw bytes or a file-like object (Django UploadedFile).
        """
        if hasattr(uploaded, "read"):
            # ensure pointer at start (defensive)
            try:
                uploaded.seek(0)
            except Exception:
                pass
            content = uploaded.read()
            # rewind if possible for caller's later use
            try:
                uploaded.seek(0)
            except Exception:
                pass
            return content
        return uploaded

    @staticmethod
    def _extract_file_metadata(uploaded, content: bytes):
        size = getattr(uploaded, "size", len(content))
        name = getattr(uploaded, "name", "unnamed_file")
        mime = (
            getattr(uploaded, "content_type", None)
            or mimetypes.guess_type(name)[0]
            or "application/octet-stream"
        )
        return size, name, mime

    @staticmethod
    def _bucket_name():
        bucket = getattr(settings, "AWS_STORAGE_BUCKET_NAME", None)
        if not bucket:
            raise ImproperlyConfigured("S3 bucket missing.")
        return bucket

    @staticmethod
    def _query_by_instance_or_id(
        instance=None,
        file_id=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
    ) -> QuerySet:
        """
        Query files by:
            1. instance
            2. ref_id + ref_type + ref_field
            3. ref_id + ref_type
            4. file_id
        """

        # Priority 1: instance
        if instance:
            ref_type, ref_id = extract_ref_from_instance(instance)
            qs = WdgStorageModel.objects.by_reference(ref_id, ref_type)

            if ref_field:
                qs = qs.filter(ref_field=ref_field)

            return qs

        # Priority 2:
        # explicit reference + field
        if ref_id and ref_type and ref_field:
            return WdgStorageModel.objects.filter(
                ref_id=ref_id,
                ref_type=ref_type,
                ref_field=ref_field,
            )

        # Priority 3:
        # explicit reference only
        if ref_id and ref_type:
            return WdgStorageModel.objects.by_reference(
                ref_id,
                ref_type,
            )

        # Priority 4: file ids
        ids = FileStorageService._ensure_list(file_id)
        return WdgStorageModel.objects.filter(pk__in=ids)

    @staticmethod
    def _get_s3_engine(engine_type: str):
        """Return correct S3Storage instance (presigned or direct)."""
        if engine_type == EngineChoices.DIRECTLY:
            return S3Storage()
        elif engine_type == EngineChoices.PRESIGNED:
            return S3Storage(
                endpoint_url=_WDG_STORAGE_PROXY_URL,
                presign_expire=_AWS_S3_PRESIGN_EXPIRE,
            )
        else:
            raise ValueError(f"Invalid engine_type: {engine_type}")

    @staticmethod
    def _build_file_url(obj, read_engine: str, use_cache: bool = True) -> str:
        """Generate a final file URL (presign, ed or direct) with cached signature."""
        s3_engine = FileStorageService._get_s3_engine(read_engine)
        url = (
            s3_engine.presigned_file_url(obj.storage_path)
            if read_engine == EngineChoices.PRESIGNED
            else s3_engine.direct_file_url(obj.storage_path)
        )

        if not url:
            logger.error("Failed to generate download URL for %s", obj.storage_path)
            raise RuntimeError(
                f"Failed to generate download URL for {obj.storage_path}"
            )

        if not use_cache:
            return url

        return get_cached_url(url, obj.stored_filename)

    @staticmethod
    def _extract_url_expiry(url: str):
        query = parse_qs(urlparse(url).query)

        # SigV2 style
        expires = query.get("Expires")
        if expires:
            return datetime.fromtimestamp(int(expires[0]), tz=dt_timezone.utc)

        # SigV4 style
        # amz_date = query.get("X-Amz-Date")
        # amz_expires = query.get("X-Amz-Expires")

        # if amz_date and amz_expires:
        #     base = datetime.strptime(amz_date[0], "%Y%m%dT%H%M%SZ")
        #     base = base.replace(tzinfo=timezone.utc)

        #     return base + timedelta(seconds=int(amz_expires[0]))

        return None

    @staticmethod
    def _format_storage_response(f: WdgStorageModel, url: str = None):
        """Return file metadata formatted exactly like API response."""

        expires_at = FileStorageService._extract_url_expiry(url)
        expires_in = None
        if expires_at:
            expires_in = (expires_at - dj_timezone.now()).total_seconds()
            expires_in = max(0, int(expires_in))  # prevent negative values

        return {
            "file_id": f.file_id,
            "original_filename": f.original_filename,
            "stored_filename": f.stored_filename,
            "file_type": f.mime_type,
            "ref_type": f.ref_type if f.ref_type else None,
            "ref_id": f.ref_id if f.ref_id else None,
            "ref_field": f.ref_field if f.ref_field else None,
            "file_size": f.file_size,
            "access_level": f.access_level,
            "description": f.description,
            "create_date": f.create_date,
            "write_date": f.write_date,
            "create_uid": f.create_uid if f.create_uid else None,
            "write_uid": f.write_uid if f.write_uid else None,
            "deleted": f.deleted,
            "url": url,
            "url_expires_at": expires_at.isoformat() if expires_at else None,
            "url_expires_in": expires_in,
        }

    # -------------------------
    # Save / Upload
    # -------------------------
    @staticmethod
    def save_file(
        validated_data, storage_provider="AWS_S3", instance=None, **kwargs
    ) -> List:
        """
        Upload one or many files. Returns list of created file_ids.
        Raises RuntimeError on any upload failure.
        """
        responses = []

        files = validated_data["file"]
        read_engine = validated_data["read_engine"]
        access_level = validated_data["access_level"]
        upload_engine = validated_data["upload_engine"]
        response_type = validated_data["response_type"]
        if not isinstance(files, (list, tuple)):
            files = [files]

        s3_upload_engine = FileStorageService._get_s3_engine(engine_type=upload_engine)
        for uploaded in FileStorageService._ensure_list(files):
            # read bytes (this returns bytes for both bytes and UploadedFile)
            file_bytes = FileStorageService._extract_file_bytes(uploaded)

            size, original_name, mime = FileStorageService._extract_file_metadata(
                uploaded, file_bytes
            )
            stored_name = unique_file_name(original_name)
            sha256, _ = compute_checksums(file_bytes)
            use_temp = kwargs.get("use_temp", True)
            ref_field = kwargs.get("ref_field", None)
            status = kwargs.get("status", UploadStatus.PENDING)
            obj_create_date = kwargs.get("obj_create_date", None)

            key = build_storage_path(
                filename=stored_name,
                is_temp=use_temp,
                date=obj_create_date,
                instance=None if use_temp else instance,
            )

            # upload raw bytes (raise on failure)
            result = s3_upload_engine.upload_fileobj(
                key=key,
                mime_type=mime,
                file_bytes=file_bytes,
                upload_engine=upload_engine,
                access_level=access_level,
            )
            if not result.get("success"):
                err = result.get("error") or "Unknown upload error"
                logger.error("S3 upload failed for key=%s: %s", key, err)
                raise RuntimeError(f"S3 upload failed for {key}: {err}")

            # create DB record
            obj = WdgStorageModel.objects.create(
                original_filename=original_name,
                stored_filename=stored_name,
                mime_type=mime,
                file_size_bytes=size,
                checksum=sha256,
                storage_path=key,
                access_level=access_level,
                storage_provider=storage_provider,
                status=status,
                ref_field=ref_field,
            )

            apply_reference(instance, obj)
            obj.save()

            if response_type == ResponseTypeChoices.ID_ONLY:
                responses.append(str(obj.file_id))
            else:
                url = FileStorageService._build_file_url(obj, read_engine, False)
                responses.append(FileStorageService._format_storage_response(obj, url))
        return responses

    # -------------------------
    # Update
    # -------------------------
    @staticmethod
    def update_file(file_id=None, new_file=None, instance=None, is_success=True):
        if not file_id:
            raise ValueError("file_id required.")

        if new_file is None:
            FileStorageService._update_metadata_only(file_id, instance, is_success)
            return FileStorageService._ensure_list(file_id)

        return FileStorageService._replace_files(
            file_id, new_file, instance, is_success
        )

    @staticmethod
    def _update_metadata_only(file_id, instance, is_success):
        qs = FileStorageService._query_by_instance_or_id(file_id=file_id)
        for f in qs:
            f.status = UploadStatus.COMPLETED if is_success else UploadStatus.FAILED
            apply_reference(instance, f)
            f.save()

    @staticmethod
    def _replace_files(file_id, new_file, instance, is_success):
        s3_engine = S3Storage(
            endpoint_url=_WDG_STORAGE_PROXY_URL, presign_expire=_AWS_S3_PRESIGN_EXPIRE
        )
        updated_ids: List[str] = []

        file_ids = FileStorageService._ensure_list(file_id)
        new_files = FileStorageService._ensure_list(new_file)

        for idx, fid in enumerate(file_ids):
            f = WdgStorageModel.objects.filter(file_id=fid).first()
            if not f:
                raise ValueError(f"File with id {fid} not found.")

            uploaded = new_files[idx]
            file_bytes = FileStorageService._extract_file_bytes(uploaded)
            size, original_name, mime = FileStorageService._extract_file_metadata(
                uploaded, file_bytes
            )

            stored_name = unique_file_name(original_name)
            sha256, _ = compute_checksums(file_bytes)
            key = FileStorageService._key(stored_name)

            result = s3_engine.upload_fileobj(
                key=key, mime_type=mime, file_bytes=file_bytes
            )
            if not result.get("success"):
                err = result.get("error") or "Unknown upload error"
                logger.error("S3 upload failed for key=%s: %s", key, err)
                raise RuntimeError(f"S3 upload failed for {key}: {err}")

            f.original_filename = original_name
            f.stored_filename = stored_name
            f.mime_type = mime
            f.file_size_bytes = size
            f.storage_path = key
            f.checksum = sha256
            f.status = UploadStatus.COMPLETED if is_success else UploadStatus.FAILED

            apply_reference(instance, f)
            f.save()

            updated_ids.append(f.file_id)

        return updated_ids

    # -------------------------
    # Delete / Restore
    # -------------------------
    @staticmethod
    def delete(
        instance=None,
        file_id=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
        soft=False,
    ):
        qs = FileStorageService._query_by_instance_or_id(
            instance,
            file_id,
            ref_id,
            ref_type,
            ref_field,
        )
        files = list(qs)
        if not files:
            return 0

        if soft:
            return FileStorageService._soft_delete(files, instance)
        return FileStorageService._hard_delete(files)

    @staticmethod
    def _soft_delete(files, instance):
        count = 0
        for f in files:
            f.deleted = True
            f.status = UploadStatus.FAILED
            apply_reference(instance, f)
            f.save(update_fields=["deleted", "status", "write_uid", "write_date"])
            count += 1
        return count

    @staticmethod
    def _hard_delete(files):
        count = 0
        s3_engine = S3Storage()
        for f in files:
            key = f.storage_path
            try:
                ok = s3_engine.delete_file(key)
                if not ok:
                    raise RuntimeError(f"Failed to delete S3 object {key}")
            except ClientError as e:
                logger.exception("Failed to delete S3 object %s: %s", key, e)
                raise
            except Exception as e:
                logger.exception("Unexpected error deleting S3 object %s: %s", key, e)
                raise

            try:
                f.delete()
                count += 1
            except Exception as e:
                logger.exception(
                    "Failed to delete DB record (file_id=%s): %s", f.file_id, e
                )
                raise

        return count

    @staticmethod
    def restore(
        instance=None, file_id=None, ref_id=None, ref_type=None, ref_field=None
    ):
        qs = FileStorageService._query_by_instance_or_id(
            instance, file_id, ref_id, ref_type, ref_field
        ).filter(deleted=True)
        files = list(qs)
        if not files:
            return 0

        count = 0
        for f in files:
            f.deleted = False
            f.status = UploadStatus.COMPLETED
            apply_reference(instance, f)
            f.save()
            count += 1

        return count

    # -------------------------
    # Download (presigned True/False)
    # -------------------------
    @staticmethod
    def download_file_url(
        file_id=None,
        instance=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
        presigned=True,
        include_deleted=False,
    ):
        qs = FileStorageService._query_by_instance_or_id(
            instance=instance,
            file_id=file_id,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
        )

        if not include_deleted:
            qs = qs.filter(deleted=False)

        files = list(qs)

        if not files:
            raise ValueError(NO_FILES_FOUND)

        results = []
        read_engine = EngineChoices.PRESIGNED if presigned else EngineChoices.DIRECTLY

        for f in files:
            url = FileStorageService._build_file_url(f, read_engine)
            results.append(FileStorageService._format_storage_response(f, url))

        return results
    
    @staticmethod
    def copy_object(
        source_key: str,
        instance: Optional[Model] = None,
        storage_provider: str = "AWS_S3",
        access_level: str = "private",
        ref_id=None,
        ref_type: Optional[str] = None,
        ref_field: Optional[str] = None,
    ):
        """
        Copy an existing S3 object and create a new WdgStorageModel record.

        Priority:
        1. instance
        2. explicit ref_id/ref_type
        3. no reference (pending/temp file)
        """

        if not source_key:
            return None

        # -------------------------
        # Source file metadata
        # -------------------------
        source_obj = WdgStorageModel.objects.get(storage_path=source_key)

        original_name = source_obj.original_filename or os.path.basename(source_key)
        stored_name = unique_file_name(original_name)

        # -------------------------
        # Resolve references
        # Priority:
        # instance > ref_id/ref_type
        # -------------------------
        resolved_ref_id = None
        resolved_ref_type = None

        if instance:
            resolved_ref_id = str(instance.pk)
            resolved_ref_type = instance._meta.model_name

        elif ref_id and ref_type:
            resolved_ref_id = str(ref_id)
            resolved_ref_type = ref_type

        # -------------------------
        # Build storage path
        # Keep temp until attached
        # -------------------------
        key = build_storage_path(
            filename=stored_name,
            instance=instance,
            is_temp=not bool(instance),
        )

        # -------------------------
        # Copy object in S3
        # -------------------------
        result = S3Storage().copy_object(
            source_key=source_key,
            dest_key=key,
        )

        if not result:
            raise RuntimeError(f"S3 copy failed for {source_key} -> {key}")

        # -------------------------
        # Create DB record
        # -------------------------
        obj = WdgStorageModel.objects.create(
            original_filename=original_name,
            stored_filename=stored_name,
            mime_type=source_obj.mime_type,
            file_size_bytes=source_obj.file_size_bytes,
            checksum=source_obj.checksum,
            storage_path=key,
            access_level=access_level,
            storage_provider=storage_provider,
            status=(
                UploadStatus.COMPLETED
                if (instance or resolved_ref_id)
                else UploadStatus.PENDING
            ),
            ref_id=resolved_ref_id,
            ref_type=resolved_ref_type,
            ref_field=ref_field,
        )

        # -------------------------
        # Attach reference if instance provided
        # -------------------------
        if instance:
            apply_reference(instance, obj)
            obj.save()

        # -------------------------
        # Response
        # -------------------------
        url = FileStorageService._build_file_url(
            obj,
            EngineChoices.PRESIGNED,
            False,
        )

        return FileStorageService._format_storage_response(
            obj,
            url,
        )
