import logging
from pathlib import Path

from django.conf import settings
from django.core.files.base import ContentFile
from django.core.files.storage import FileSystemStorage

logger = logging.getLogger(__name__)


class FileSystem:
    """
    Local filesystem storage engine.

    Physical storage root:

        <BASE_DIR>/storages/

    Example keys:

        uploads/2026/payroll/file.xlsx
        temp/2026/common/file.xlsx
    """

    def __init__(self):

        # =================================================
        # STORAGE ROOT
        # =================================================

        self.base_storage_path = Path(
            settings.BASE_DIR,
            "storages",
        ).resolve()

        self.base_storage_path.mkdir(
            parents=True,
            exist_ok=True,
        )

        # =================================================
        # DJANGO STORAGE
        # =================================================

        self.storage = FileSystemStorage(
            location=str(self.base_storage_path),
            base_url="/storages/",
        )

    # =====================================================
    # NORMALIZE KEY
    # =====================================================

    @staticmethod
    def _normalize_key(key: str) -> str:
        """
        Normalize Django storage key.
        """

        if not key:
            raise ValueError("Storage key is required.")

        return key.lstrip("/")

    # =====================================================
    # UPLOAD FILE
    # =====================================================

    def upload_fileobj(
        self,
        key: str,
        file_bytes: bytes,
    ) -> dict:
        """
        Save file to local filesystem.
        """

        try:

            key = self._normalize_key(key)

            # Replace existing file
            if self.storage.exists(key):
                self.storage.delete(key)

            # Save file
            saved_key = self.storage.save(
                key,
                ContentFile(file_bytes),
            )

            return {
                "success": True,
                "key": saved_key,
                "path": self.storage.path(saved_key),
                "url": self.storage.url(saved_key),
            }

        except Exception as exc:

            logger.exception(
                "Local filesystem upload failed",
            )

            return {
                "success": False,
                "error": str(exc),
                "key": key,
            }

    # =====================================================
    # GET FILE
    # =====================================================

    def get_file(
        self,
        key: str,
    ) -> bytes | None:
        """
        Read file bytes.
        """

        try:

            key = self._normalize_key(key)

            if not self.storage.exists(key):
                return None

            with self.storage.open(
                key,
                "rb",
            ) as file:

                return file.read()

        except Exception:

            logger.exception(
                "Failed to read file",
            )

            return None

    # =====================================================
    # GET FILE URL
    # =====================================================

    def get_url(
        self,
        key: str,
    ) -> str:
        """
        Get public URL.
        """

        key = self._normalize_key(key)

        return self.storage.url(key)

    # =====================================================
    # DELETE FILE
    # =====================================================

    def delete_file(
        self,
        key: str,
    ) -> bool:
        """
        Delete file from storage.
        """

        try:

            key = self._normalize_key(key)

            if self.storage.exists(key):
                self.storage.delete(key)

            return True

        except Exception:

            logger.exception(
                "Failed to delete file",
            )

            return False

    # =====================================================
    # MOVE FILE
    # =====================================================

    def move_object(
        self,
        source_key: str,
        dest_key: str,
    ) -> bool:
        """
        Move file inside local storage.
        """

        try:

            source_key = self._normalize_key(source_key)
            dest_key = self._normalize_key(dest_key)

            source_path = Path(self.storage.path(source_key))

            dest_path = Path(self.storage.path(dest_key))

            # Ensure destination folder exists
            dest_path.parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            # Replace existing file
            if self.storage.exists(dest_key):
                self.storage.delete(dest_key)

            # Move file
            source_path.rename(dest_path)

            return True

        except Exception:

            logger.exception(
                "Failed to move file",
            )

            return False
