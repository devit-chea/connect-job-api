from rest_framework import serializers
from wdg_storage.config import get_upload_config
from wdg_storage.validators.size_validator import SizeValidator
from wdg_storage.validators.manager import FileValidationManager
from wdg_storage.validators.extension_validator import ExtensionValidator
from wdg_storage.constant import ResponseTypeChoices, AccessLevelChoices, EngineChoices


class BaseFileUploadSerializer(serializers.Serializer):
    """
    Base serializer for handling single or multiple file uploads.

    It automatically loads configuration from `get_upload_config()`,
    and applies validation through the FileValidationManager using
    ExtensionValidator, SizeValidator, and any custom validators
    defined in Django settings.
    """

    file = serializers.ListField(
        child=serializers.FileField(),
        required=True,
        allow_empty=False,
    )
    read_engine = serializers.ChoiceField(
        choices=EngineChoices.choices,
        default=EngineChoices.PRESIGNED,
        required=False,
    )
    upload_engine = serializers.ChoiceField(
        choices=EngineChoices.choices,
        default=EngineChoices.DIRECTLY,
        required=False,
    )
    access_level = serializers.ChoiceField(
        choices=AccessLevelChoices.choices,
        default=AccessLevelChoices.PRIVATE,
        required=False,
    )
    response_type = serializers.ChoiceField(
        choices=ResponseTypeChoices.choices,
        default=ResponseTypeChoices.ID_ONLY,
        required=False,
    )

    def __init__(self, *args, **kwargs):
        """Initialize with dynamic configuration and validator manager."""
        config = get_upload_config()
        self.allowed_extensions = kwargs.pop(
            "allowed_extensions", config["allowed_extensions"]
        )
        self.max_file_size = kwargs.pop("max_file_size", config["max_file_size"])

        # Flatten all extensions into one list (for general validation)
        # Example: ["jpg", "png", "pdf", "docx", "mp4", ...]
        self._all_allowed_extensions = [
            ext for group in self.allowed_extensions.values() for ext in group
        ]

        # Base validators
        self.validators_list = [
            ExtensionValidator(allowed_extensions=self._all_allowed_extensions),
            SizeValidator(max_file_size=self.max_file_size),
        ]

        # Add custom validators if defined in settings
        for validator_cls in config.get("custom_validators", []):
            self.validators_list.append(validator_cls())

        self.validation_manager = FileValidationManager(self.validators_list)
        super().__init__(*args, **kwargs)

    def validate(self, attrs):
        files = attrs.get("file")

        if not files:
            raise serializers.ValidationError(
                {
                    "file": [
                        "No files were uploaded. Please select at least one file to continue."
                    ]
                }
            )

        if not isinstance(files, (list, tuple)):
            files = [files]

        try:
            # Run your validators
            self.validation_manager.validate_many(files)
        except serializers.ValidationError as exc:
            raise serializers.ValidationError({"file": exc.detail})

        return attrs
