import os
import re
import uuid
import httpx
import base64
import hashlib
import logging
from pathlib import Path
from typing import Optional
from django.conf import settings
from django.db.models import Model
from django.core.cache import caches
from datetime import datetime, timedelta, timezone
from wdg_storage.utils.tenant_util import get_tenant
from django.contrib.contenttypes.models import ContentType

logger = logging.getLogger(__name__)

# Use Django's configured caches
default_cache = caches["default"]
redis_cache = caches["redis"] if "redis" in settings.CACHES else default_cache

# Cache expiration for presigned URLs (default 5 minutes)
URL_CACHE_EXPIRE = getattr(settings, "AWS_S3_PRESIGN_EXPIRE", 3600)


# Ensure expiration is always int (seconds)
if isinstance(URL_CACHE_EXPIRE, timedelta):
    URL_CACHE_EXPIRE = int(URL_CACHE_EXPIRE.total_seconds())
else:
    URL_CACHE_EXPIRE = int(URL_CACHE_EXPIRE)


def get_cached_url(url: str, stored_filename: str):
    """
    Returns the cached URL for a file (e.g., FileField).

    Caches the URL in Redis (if configured) to reduce repeated file lookups.
    Falls back to returning the original URL if caching fails.

    Args:
        url (str): The original file URL.
        stored_filename (str): The unique filename/key used for caching.

    Returns:
        str | None: The cached URL or the original URL, or None if url is empty.
    """
    if not url:
        return None

    cache_key = f"image_url_cache:{stored_filename}"

    # Attempt to retrieve from Redis cache
    try:
        cached_url = redis_cache.get(cache_key)
        if cached_url:
            return cached_url
    except Exception:
        # Redis might not be configured or reachable
        pass

    # Cache the URL for future use
    try:
        redis_cache.set(cache_key, url, timeout=URL_CACHE_EXPIRE)
    except Exception:
        pass

    return url


def add_slash(path):
    """
    Ensures a string ends with a '/'.

    Args:
        path (str): The input string.

    Returns:
        str: The string with a trailing '/'.
    """

    return path if path.endswith("/") else path + "/"


def compute_checksums(file):
    """
    Compute SHA256 and MD5 checksums for both file-like objects and bytes.
    """
    if isinstance(file, (bytes, bytearray)):
        data = file
    else:
        file.seek(0)
        data = file.read()
        file.seek(0)

    md5 = hashlib.md5(data).hexdigest()
    sha256 = hashlib.sha256(data).hexdigest()

    return sha256, md5


def unique_file_name(original_filename):
    base, ext = os.path.splitext(original_filename)

    sanitized_name = re.sub(r"[^A-Za-z0-9_-]", "_", base)

    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    unique_id = uuid.uuid4().hex[:8]

    return f"{sanitized_name}_{timestamp}_{unique_id}{ext}"


def build_storage_path(
    *,
    filename: str,
    instance: Optional[Model] = None,
    ref_type: Optional[str] = None,
    date: Optional[datetime] = None,
    is_temp: bool = False,
) -> str:
    """
    Build storage object path.

    Final:
      [_RAW]/tenant/year/content_type/filename

    Temp:
      [_RAW]/tenant/temp/year/common/filename
    """

    date = date or datetime.now(timezone.utc)
    year = date.year
    tenant = get_tenant()

    if is_temp:
        content_type = "common"

    elif ref_type:
        content_type = ref_type

    elif instance:
        content_type = get_content_type(instance)

    else:
        raise ValueError(
            "Either instance or ref_type must be provided " "when is_temp=False."
        )

    parts: list[str] = []

    raw_path = getattr(settings, "WDG_STORAGE_PATH", None)
    if raw_path:
        parts.append(raw_path.strip("/"))

    tenant_path = resolve_tenant_path(tenant)
    if tenant_path:
        parts.append(tenant_path)

    if is_temp:
        parts.append("temp")

    parts.extend([str(year), content_type, filename])

    return "/".join(parts)


def build_local_storage_path(
    *,
    filename: str,
    instance: Optional[Model] = None,
    is_temp: bool = False,
) -> str:
    """
    Build Django storage-relative path.

    Examples:
        uploads/2026/payroll/file.xlsx
        temp/2026/common/file.xlsx
    """

    date = datetime.now(timezone.utc)

    year = str(date.year)

    root_folder = "temp" if is_temp else "thumbnails"

    if is_temp:

        content_type = "common"

    elif instance:
        content_type = get_content_type(instance)

    else:
        raise ValueError("Either instance or ref_type must be provided.")

    # Safe filename only
    filename = Path(filename).name

    return "/".join(
        [
            root_folder,
            year,
            content_type,
            filename,
        ]
    )


# -------------------------------------------------
# CONTENT TYPE
# -------------------------------------------------
def get_content_type(instance: Optional[Model]) -> str:
    if not instance:
        return "common"

    ct = ContentType.objects.get_for_model(instance.__class__)
    return ct.model


# -------------------------------------------------
# TENANT PATH RESOLVER
# -------------------------------------------------
def resolve_tenant_path(tenant: Optional[object]) -> Optional[str]:
    """
    Resolve tenant directory safely.

    - public schema → slugified tenant.name
    - normal tenant → schema_name
    - non-tenant project → None
    """
    if not tenant:
        return None

    schema_name = getattr(tenant, "schema_name", None)
    tenant_name = getattr(tenant, "name", None)

    if not schema_name:
        return None

    # PUBLIC schema → readable tenant name
    if schema_name == "public" and tenant_name:
        return re.sub(r"[\s]+|[^\w]", "_", tenant_name).strip("_").lower()

    return str(schema_name)


def get_image_base64(
    url: str, mime_type: str = "image/png", data_uri: bool = False
) -> str | None:
    """
    Fetches an image from a URL and returns it as a base64-encoded string.

    Args:
        url (str): The URL of the image.
        mime_type (str, optional): MIME type for data URI. Defaults to "image/png".
        data_uri (bool, optional): If True, returns a full data URI string.

    Returns:
        str | None: The encoded base64 string, or None on error.
    """
    if not url:
        logger.debug("No URL provided for base64 conversion.")
        return None

    try:
        with httpx.Client(timeout=5.0) as client:
            response = client.get(url)

        if response.status_code == 200:
            encoded = base64.b64encode(response.content).decode("utf-8")
            return f"data:{mime_type};base64,{encoded}" if data_uri else encoded
        else:
            logger.warning(
                f"Non-200 status code {response.status_code} for image URL: {url}"
            )
            return None

    except httpx.RequestError:
        logger.exception(f"Request error while fetching image from: {url}")
        return None
    except Exception:
        logger.exception(f"Unexpected error while encoding image from: {url}")
        return None
