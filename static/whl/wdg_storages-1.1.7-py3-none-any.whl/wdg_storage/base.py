import uuid
from typing import Optional
from django.db.models import Model
from typing import Union, List
from django.db.models import Model
from wdg_storage.constant import ProviderChoices
from wdg_storage.service import (
    FileStorageService,
    FileSystemService,
    update_file_record,
)

def _to_str(fid):
    if isinstance(fid, uuid.UUID):
        return str(fid)
    if isinstance(fid, str):
        return fid
    raise ValueError(f"Invalid file_id type: {type(fid)}")


def _normalize_from_files_data(files_data):
    items = files_data if isinstance(files_data, list) else [files_data]
    normalized = []

    for item in items:
        if not isinstance(item, dict):
            continue

        fid = item.get("file_id") if isinstance(item, dict) else None
        inst = item.get("instance") if isinstance(item, dict) else None

        normalized.append(
            {
                "file_id": _to_str(fid) if fid else None,
                "instance": inst,
                "ref_id": item.get("ref_id"),
                "ref_type": item.get("ref_type"),
                "ref_field": item.get("ref_field"),
            }
        )

    return normalized


def _normalize_from_file_id(
    file_id, instance=None, ref_id=None, ref_type=None, ref_field=None
):
    file_ids = file_id if isinstance(file_id, list) else [file_id]

    normalized = []

    for fid in file_ids:
        normalized.append(
            {
                "file_id": _to_str(fid),
                "instance": instance,
                "ref_id": ref_id,
                "ref_field": ref_field,
                "ref_type": ref_type,
            }
        )

    return normalized


def _normalize_file_inputs(
    files_data=None,
    file_id: Union[str, uuid.UUID, List[Union[str, uuid.UUID]]] = None,
    instance=None,
    ref_id=None,
    ref_type=None,
    ref_field=None,
):
    """
    Normalize all input types into a standard list of:
    [
        {
            "file_id": <str | None>,
            "instance": <Model | None>,
            "ref_id": <str | int | None>,
            "ref_type": <str | None>,
            "ref_field": <str | None>,
        }
    ]

    Supported priority:

        1. files_data
        2. file_id
        3. instance (+ optional ref_field)
        4. ref_id + ref_type + optional ref_field
    """

    # Priority 1: files_data
    if files_data is not None:
        return _normalize_from_files_data(files_data)

    # Priority 2: file_id
    if file_id is not None:
        return _normalize_from_file_id(
            file_id=file_id,
            instance=instance,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
        )

    # Priority 3: instance
    if instance is not None:
        return [
            {
                "file_id": None,
                "instance": instance,
                "ref_id": instance.pk,
                "ref_type": instance._meta.model_name,
                "ref_field": ref_field or "",
            }
        ]
    # Priority 4: explicit reference
    if ref_id is not None and ref_type is not None:
        return [
            {
                "file_id": None,
                "instance": None,
                "ref_id": ref_id,
                "ref_type": ref_type,
                "ref_field": ref_field or "",
            }
        ]

    raise ValueError(
        "You must provide one of the following:\n"
        "- files_data\n"
        "- file_id\n"
        "- instance\n"
        "- ref_id + ref_type\n"
        "- optional ref_field"
    )


# SERVICE CLASS VERSION WITH FULL DOCUMENTATION
class WdgStorageService:

    # Update files
    @staticmethod
    def update_metadata(
        files_data=None,
        file_id=None,
        instance=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
        is_success=True,
    ):
        """
        Usage:
            # Instance mode
            update_metadata(
                file_id=file_id,
                instance=employee,
                ref_field="profile_image",
            )

        """
        normalized = _normalize_file_inputs(
            files_data=files_data,
            file_id=file_id,
            instance=instance,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
        )

        updated = 0

        for item in normalized:
            updated += update_file_record(
                file_id=item["file_id"],
                ref_type=item["ref_type"],
                ref_field=item["ref_field"],
                instance=item["instance"],
                ref_id=item.get("ref_id"),
                is_success=is_success,
            )

        return updated

    # Get file metadata and (presigned True/False)
    @staticmethod
    def get_files(
        files_data=None,
        file_id=None,
        instance=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
        presigned=True,
        include_deleted=False,
    ):
        normalized = _normalize_file_inputs(
            files_data=files_data,
            file_id=file_id,
            instance=instance,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
        )
        results = []

        for item in normalized:
            file_info = FileStorageService.download_file_url(
                file_id=item.get("file_id"),
                instance=item.get("instance"),
                ref_id=item.get("ref_id"),
                ref_type=item.get("ref_type"),
                ref_field=item.get("ref_field"),
                presigned=presigned,
                include_deleted=include_deleted,
            )
            results.extend(file_info)
        return results

    # Download file and (presigned True/False)
    @staticmethod
    def download_files(
        files_data=None,
        file_id=None,
        instance=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
        presigned=True,
        include_deleted=False,
    ):
        normalized = _normalize_file_inputs(
            files_data=files_data,
            file_id=file_id,
            instance=instance,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
        )

        urls = []
        for item in normalized:
            file_info = FileStorageService.download_file_url(
                file_id=item["file_id"],
                instance=item["instance"],
                ref_id=item.get("ref_id"),
                ref_type=item.get("ref_type"),
                ref_field=item.get("ref_field"),
                presigned=presigned,
                include_deleted=include_deleted,
            )
            urls.append(file_info)
        return urls

    # GET file and (presigned True/False)
    @staticmethod
    def get_file_url(
        files_data=None,
        file_id=None,
        instance=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
        presigned=True,
        include_deleted=False,
    ):
        """
        Get a single presigned URL for a file.

        Returns the URL of the first file found, or None if not found.
        """
        normalized = _normalize_file_inputs(
            files_data=files_data,
            file_id=file_id,
            instance=instance,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
        )

        if not normalized:
            return None

        first_item = normalized[0]
        file_info = FileStorageService.download_file_url(
            file_id=first_item["file_id"],
            instance=first_item["instance"],
            ref_id=first_item.get("ref_id"),
            ref_type=first_item.get("ref_type"),
            ref_field=first_item.get("ref_field"),
            presigned=presigned,
            include_deleted=include_deleted,
        )

        if not file_info:
            return None

        return file_info[0]["url"]

    # Delete file and (soft True/False)
    @staticmethod
    def delete_files(
        instance=None,
        file_id=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
        soft=False,
    ) -> str:

        deleted_count = FileStorageService.delete(
            instance=instance,
            file_id=file_id,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
            soft=soft,
        )

        if deleted_count == 0:
            message = "No files were deleted."
        elif deleted_count == 1:
            message = "1 file deleted successfully."
        else:
            message = f"{deleted_count} files deleted successfully."

        return message

    # Restore files
    @staticmethod
    def restore_files(
        instance=None,
        file_id=None,
        ref_id=None,
        ref_type=None,
        ref_field=None,
    ) -> str:

        restore_count = FileStorageService.restore(
            instance=instance,
            file_id=file_id,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
        )

        if restore_count == 0:
            message = "No files were restored."
        elif restore_count == 1:
            message = "1 file restored successfully."
        else:
            message = f"{restore_count} files restored successfully."

        return message

    @staticmethod
    def copy_object(
        source_key: str,
        instance: Optional[Model] = None,
        storage_provider: str = "AWS_S3",
        access_level: str = "private",
        ref_id=None,
        ref_type: Optional[str] = None,
        ref_field: Optional[str] = None,
    ):
        return FileStorageService.copy_object(
            source_key=source_key,
            instance=instance,
            storage_provider=storage_provider,
            access_level=access_level,
            ref_id=ref_id,
            ref_type=ref_type,
            ref_field=ref_field,
        )

    # LOCAL FILESYSTEM

    @staticmethod
    def save_filesystem(
        *,
        file=None,
        file_bytes=None,
        filename=None,
        instance: Model,
        module="common",
        mime_type="application/octet-stream",
        ref_field="",
        **kwargs,
    ):
        """
        Save file into local filesystem.

        Supports:
            - UploadedFile
            - bytes
            - export files
            - BytesIO

        Example:
            save_filesystem(
                file=request.FILES["file"],
                instance=employee,
            )

            save_filesystem(
                file_bytes=output.getvalue(),
                filename="report.xlsx",
                instance=payrun,
            )
        """

        return FileSystemService.save_filesystem(
            file=file,
            file_bytes=file_bytes,
            filename=filename,
            instance=instance,
            module=module,
            mime_type=mime_type,
            ref_field=ref_field,
            **kwargs,
        )

    @staticmethod
    def get_filesystem_url(instance: Model, ref_field=""):
        """
        Get latest local filesystem file URL.
        """

        return FileSystemService.get_url_by_reference(
            instance=instance,
            ref_field=ref_field,
        )

    @staticmethod
    def get_filesystem_obj(
        instance: Model,
        ref_field="",
        storage_provider: str = ProviderChoices.LOCAL_FILESYSTEM,
    ):
        """
        Get latest local filesystem file URL.
        """

        return FileSystemService.get_obj_by_reference(
            instance=instance,
            ref_field=ref_field,
            storage_provider=storage_provider,
        )

    @staticmethod
    def delete_filesystem_file(key: str):
        """
        Delete direct URL from storage object.

        key: storage_path
        """

        return FileSystemService.delete_file(key)

    @staticmethod
    def delete_filesystem_files(instance: Model, ref_field=""):
        """
        Get latest local filesystem file URL.
        """

        return FileSystemService.delete_file_by_reference(
            instance=instance,
            ref_field=ref_field,
        )


# MIXIN VERSION
class WdgStorageMixin:

    def update_metadata(self, *args, **kwargs):
        return WdgStorageService.update_metadata(*args, **kwargs)

    def get_files(self, *args, **kwargs):
        return WdgStorageService.get_files(*args, **kwargs)

    def download_files(self, *args, **kwargs):
        return WdgStorageService.download_files(*args, **kwargs)

    def get_file_url(self, *args, **kwargs):
        return WdgStorageService.get_file_url(*args, **kwargs)

    def delete_files(self, *args, **kwargs):
        return WdgStorageService.delete_files(*args, **kwargs)

    def restore_files(self, *args, **kwargs):
        return WdgStorageService.restore_files(*args, **kwargs)
    
    def copy_object(self, *args, **kwargs):
        return WdgStorageService.copy_object(*args, **kwargs)

    # LOCAL FILESYSTEM
    def save_filesystem(self, *args, **kwargs):
        return WdgStorageService.save_filesystem(*args, **kwargs)

    def get_filesystem_url(self, *args, **kwargs):
        return WdgStorageService.get_filesystem_url(*args, **kwargs)

    def get_filesystem_obj(self, *args, **kwargs):
        return WdgStorageService.get_filesystem_obj(*args, **kwargs)

    def delete_filesystem_file(self, *args, **kwargs):
        return WdgStorageService.delete_filesystem_file(*args, **kwargs)

    def delete_filesystem_files(self, *args, **kwargs):
        return WdgStorageService.delete_filesystem_files(*args, **kwargs)


#  FUNCTION VERSION
def update_metadata(*args, **kwargs):
    return WdgStorageService.update_metadata(*args, **kwargs)


def get_files(*args, **kwargs):
    return WdgStorageService.get_files(*args, **kwargs)


def download_files(*args, **kwargs):
    return WdgStorageService.download_files(*args, **kwargs)


def get_file_url(*args, **kwargs):
    return WdgStorageService.get_file_url(*args, **kwargs)


def delete_files(*args, **kwargs):
    return WdgStorageService.delete_files(*args, **kwargs)


def restore_files(*args, **kwargs):
    return WdgStorageService.restore_files(*args, **kwargs)

def copy_object(*args, **kwargs):
    return WdgStorageService.copy_object(*args, **kwargs)


# LOCAL FILESYSTEM
def save_filesystem(*args, **kwargs):
    return WdgStorageService.save_filesystem(*args, **kwargs)


def get_filesystem_url(*args, **kwargs):
    return WdgStorageService.get_filesystem_url(*args, **kwargs)


def get_filesystem_obj(*args, **kwargs):
    return WdgStorageService.get_filesystem_obj(*args, **kwargs)


def delete_filesystem_file(*args, **kwargs):
    return WdgStorageService.delete_filesystem_file(*args, **kwargs)


def delete_filesystem_files(*args, **kwargs):
    return WdgStorageService.delete_filesystem_files(*args, **kwargs)
