class Utils:
    def query_params(query_params=None):
        if query_params is None:
            query_params = {}
        elif isinstance(query_params, dict):
            query_params = "&".join(
                f"{key}={value}" for key, value in query_params.items()
            )
        elif isinstance(query_params, str):
            query_params = query_params
        else:
            raise ValueError("query_params must be a dict or str")

        return query_params
