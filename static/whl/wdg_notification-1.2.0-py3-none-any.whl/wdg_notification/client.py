import requests
from bs4 import BeautifulSoup

from .exceptions import APIError


class NotificationClient:
    def __init__(self, base_url, app_id, secret_key, timeout=3):
        self.base_url = base_url
        self.app_id = app_id
        self.secret_key = secret_key
        self.session = requests.Session()
        self.session.headers.update(
            {
                "X-App-ID": self.app_id,
                "X-Secret-Key": self.secret_key,
            }
        )
        self.timeout = timeout

    def _request(self, method, endpoint, **kwargs):
        url = f"{self.base_url}{endpoint}"
        if "timeout" not in kwargs:
            kwargs["timeout"] = self.timeout

        try:
            response = self.session.request(method, url, **kwargs)
        except requests.Timeout:
            raise APIError(504, "Notification Request timeout")
        except requests.RequestException as e:
            raise APIError(500, str(e))

        if not response.ok:
            error_message = None

            try:
                if response.text.strip():
                    error_data = response.json()
                    error_message = (
                        error_data.get("message")
                        or error_data.get("error")
                        or str(error_data)
                    )
            except ValueError:
                pass

            if not error_message and response.text.strip().startswith(
                "<!doctype html>"
            ):
                soup = BeautifulSoup(response.text, "html.parser")
                error_message = (
                    soup.h1.get_text(strip=True)
                    if soup.h1
                    else (
                        soup.title.get_text(strip=True)
                        if soup.title
                        else f"HTTP {response.status_code} error"
                    )
                )

            if not error_message:
                error_message = f"HTTP {response.status_code} error"

            raise APIError(response.status_code, error_message)

        return response

    def send_notification(self, data):
        return self._request("POST", "/api/notifications/send", json=data)

    def get_notifications(self, query_params=None):
        """Query Parameters:

        You can filter notifications by adding query parameters to the URL.
        Also, you can filter by Metadata Json fields with level you prepare on sending notification payload.

        example :
            receiver_id: 1
            metadata__key: value
            metadata__key__key: value
            status: read | unread | None : default = None
            is_popup: True | False | None : default = False
        """

        return self._request("GET", f"/api/notifications?{query_params}").json()

    def get_notification(self, notification_id, query_params=None):
        return self._request(
            "GET", f"/api/notifications/{notification_id}?{query_params}"
        ).json()

    def get_unread_count(self, query_params=None):
        return self._request("GET", f"/api/notifications/unread?{query_params}").json()

    def mark_as_read(self, notification_id, query_params=None):
        return self._request(
            "PUT", f"/api/notifications/{notification_id}/mark-as-read?{query_params}"
        ).json()

    def mark_all_read(self, query_params=None):
        return self._request("PUT", f"/api/notifications/mark-all-read?{query_params}")

    def get_user_notification_config(self, query_params=None):
        return self._request("GET", f"/api/user_notification/?{query_params}")

    def toggle_notification(self, data):
        return self._request("POST", "/api/user_notification/", json=data)

    def sent_telegram_message(self, data):
        return self._request("POST", "/api/telegram/sent_message", json=data)
