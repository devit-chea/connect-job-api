import os
from pathlib import Path
from environs import Env

DEBUG = True

BASE_DIR = Path(__file__).resolve().parent.parent.parent
env = Env()
env.read_env()

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": os.path.join(BASE_DIR, "db.sqlite3"),
    }
}

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

AUTH_PASSWORD_VALIDATORS = [{"NAME": "testapp.validators.Is666"}]

SECRET_KEY = "_"

MIDDLEWARE = ["django.contrib.sessions.middleware.SessionMiddleware"]


INSTALLED_APPS = (
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.staticfiles",
    "rest_framework",
    "wdg_core_file_storage.wdg_file_metadata",
)

STATIC_URL = "/static/"

REST_FRAMEWORK = {
    "DEFAULT_PERMISSION_CLASSES": ("rest_framework.permissions.IsAuthenticated",),
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework_simplejwt.authentication.JWTAuthentication",
        "rest_framework.authentication.TokenAuthentication",
    ),
}

ROOT_URLCONF = "configs.urls"

TEMPLATES = [
    {"BACKEND": "django.template.backends.django.DjangoTemplates", "APP_DIRS": True}
]

AUTHENTICATION_BACKENDS = [
    "django.contrib.auth.backends.ModelBackend",
    "djoser.social.backends.facebook.FacebookOAuth2Override",
    "social_core.backends.google.GoogleOAuth2",
    "social_core.backends.steam.SteamOpenId",
]

SIMPLE_JWT = {}

# S3 by PowerScale
S3_ACCESS_KEY_ID = env.str("S3_ACCESS_KEY_ID", None)
S3_SECRET_ACCESS_KEY = env.str("S3_SECRET_ACCESS_KEY", None)
S3_STORAGE_BUCKET_NAME = env.str("S3_STORAGE_BUCKET_NAME", None)
S3_ENDPOINT_URL = env.str("S3_ENDPOINT_URL", None)
S3_REGION_NAME = None
S3_PRESIGNED_EXPIRE = 3600