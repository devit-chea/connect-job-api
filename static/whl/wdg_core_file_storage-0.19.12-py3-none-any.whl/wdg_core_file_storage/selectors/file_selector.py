from wdg_core_file_storage.wdg_file_metadata.models import FileStorageModel


@staticmethod
def get_files_by_id(id):
    try:
        return FileStorageModel.objects.filter(id=id).first()
    except FileStorageModel.DoesNotExist:
        return None


@staticmethod
def get_files_by_file_id(file_id):
    try:
        return FileStorageModel.objects.filter(file_id=file_id).first()
    except FileStorageModel.DoesNotExist:
        return None


@staticmethod
def get_files_by_ref_type_and_ids(ref_type, file_id: list):
    try:
        return (
            FileStorageModel.objects.order_by("-id")
            .filter(file_id__in=file_id, ref_type=ref_type)
            .get()
        )
    except FileStorageModel.DoesNotExist:
        return None


@staticmethod
def get_files_by_ref_type_and_ids(ref_type, ref_id: list):
    try:
        return (
            FileStorageModel.objects.order_by("-id")
            .filter(ref_id__in=ref_id, ref_type=ref_type)
            .get()
        )
    except FileStorageModel.DoesNotExist:
        return None
