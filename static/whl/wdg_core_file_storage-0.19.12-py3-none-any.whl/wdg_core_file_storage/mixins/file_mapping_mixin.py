import logging

from django.contrib.contenttypes.models import ContentType
from wdg_core_file_storage.utils.file_util import get_image_as_base64
from wdg_core_file_storage.wdg_file_metadata.models import FileStorageModel


class FileMappingMixin:

    class Meta:
        image_base64 = False

    def to_representation(self, instance):
        """
        Override to add file_path based on ref_id from the File model,
        using ContentType from serializer's Meta.model.
        """
        # Get the original serialized data
        data = super().to_representation(instance)

        try:
            # Get ContentType for the model
            content_type = ContentType.objects.get_for_model(self.Meta.model)

            # Find the related object using the instance's ID
            file = (
                FileStorageModel.objects.filter(
                    ref_id=instance.id, ref_type=content_type.model
                )
                .order_by("-create_date")
                .first()
            )

            if file:
                # image_url = file.image_url.url if file.image_url else None

                # image_base64 = get_image_as_base64(
                #     url=image_url, mime_type=file.file_type
                # )

                # data["file_path"] = (
                #     image_base64 if image_base64 is None else file.file_path
                # )
                # data["image_url"] = image_base64 if image_base64 is None else image_url
                # if (
                #     hasattr(self.Meta, "image_base64")
                #     and self.Meta.image_base64 is True
                # ):
                #     data["image_base64"] = image_base64

                data["file_path"] = file.file_path
                data["image_url"] = file.image_url.url if file.image_url else None
            else:
                data["file_path"] = None
                data["image_url"] = None

        except ContentType.DoesNotExist:
            data["file_path"] = None
            data["image_url"] = None

        return data


class FileMappingMixinV2:
    class Meta:
        image_base64 = False

    def to_representation(self, instance):
        """
        Override to add file_path based on ref_id from the File model,
        using ContentType from serializer's Meta.model.
        """
        # Get the original serialized data
        data = super().to_representation(instance)

        try:
            content_type = ContentType.objects.get_for_model(self.Meta.model)

            file = (
                FileStorageModel.objects.filter(
                    ref_id=instance.id, ref_type=content_type.model
                )
                .order_by("-create_date")
                .first()
            )

            if file:
                image_url = file.image_url.url if file.image_url else None
                image_base64 = get_image_as_base64(
                    url=image_url, mime_type=file.file_type
                )
                data["file_path"] = (
                    image_base64 if image_base64 is None else file.file_path
                )
                data["image_url"] = image_base64 if image_base64 is None else image_url
                if getattr(self.Meta, "image_base64", False):
                    data["image_base64"] = image_base64
            else:
                data["file_path"] = None
                data["image_url"] = None

        except ContentType.DoesNotExist as e:
            logging.error(f"ContentType error: {e}")
            data["file_path"] = None
            data["image_url"] = None

        except Exception as e:
            logging.exception(f"Unexpected error in FileMappingMixin: {e}")
            data["file_path"] = None
            data["image_url"] = None

        return data
