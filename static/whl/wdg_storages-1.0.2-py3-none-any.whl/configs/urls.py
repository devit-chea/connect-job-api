"""
URL configuration for next_ping_api project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from settings.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.conf import settings
from django.urls import path, include
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView as RedocView,
    SpectacularSwaggerView as SwaggerView,
)

urlpatterns = [
    path(
        "api/v1/",
        include(
            [
                path("", include("wdg_storage.urls")),
            ]
        ),
    ),
]

if settings.DEBUG:
    urlpatterns += [
        path("schema/", SpectacularAPIView.as_view(), name="schema"),
        path("swagger/", SwaggerView.as_view(url_name="schema"), name="swagger"),
        path("redoc/", RedocView.as_view(url_name="schema"), name="redoc"),
    ]
