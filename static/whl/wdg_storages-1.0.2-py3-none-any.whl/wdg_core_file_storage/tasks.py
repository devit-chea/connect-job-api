from celery import shared_task
from wdg_core_file_storage.constants import UploadStatus
from wdg_core_file_storage.backends.s3 import S3Client
from wdg_core_file_storage.wdg_file_metadata.models import FileStorageModel
from wdg_core_file_storage.helpers.s3_helpers import get_bucket_name


@shared_task(
    name="wdg_core_file_storage.verify_file_upload",
    acks_late=True,
    bind=True,
    max_retries=5,
    default_retry_delay=10,
)
def verify_file_upload(self, file_key, user_id):
    try:
        bucket = get_bucket_name()
        s3 = S3Client()
        client = s3._get_client()
        client.head_object(Bucket=bucket, Key=file_key)
    except Exception as exc:
        # retry if not yet uploaded
        raise self.retry(exc=exc)

    # File is uploaded → trigger processing pipeline
    process_file.delay(file_key, user_id)


@shared_task
def process_file(file_key, user_id):
    # Update file info in DB
    FileStorageModel.objects.update_or_create(
        file_path=file_key,
        defaults={
            "upload_status": UploadStatus.COMPLETED,
            "write_uid": user_id,
        },
    )

    # TODO: Notify user (websocket, email, etc.)
