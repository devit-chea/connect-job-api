# wdg_core_file_storage/api/views.py

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.conf import settings

from wdg_core_file_storage.backends.s3 import S3Client
from wdg_core_file_storage.wdg_file_metadata.models import FileStorageModel


class FileUploadView(APIView):
    """
    Upload single or multiple files to S3.
    """


    def post(self, request, *args, **kwargs):
        files = request.FILES.getlist("files")
        if not files:
            return Response(
                {"error": "No files provided"}, status=status.HTTP_400_BAD_REQUEST
            )

        bucket_name = getattr(settings, "S3_STORAGE_BUCKET_NAME", None)
        if not bucket_name:
            return Response(
                {"error": "S3_STORAGE_BUCKET_NAME not configured"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        s3 = S3Client()

        try:
            if len(files) == 1:
                # Single file upload
                uploaded = s3.upload_to_s3(bucket_name, files[0])
                return Response(uploaded, status=status.HTTP_201_CREATED)
            else:
                # Multiple files (multipart upload)
                uploaded = s3.multipart_upload_multiple(bucket_name, files)
                return Response(uploaded, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response(
                {"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class FileMultipartUploadView(APIView):
    """
    Upload a large file using multipart upload.
    """

    def post(self, request, *args, **kwargs):
        file_obj = request.FILES.get("file")
        if not file_obj:
            return Response(
                {"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST
            )

        bucket_name = getattr(settings, "S3_STORAGE_BUCKET_NAME", None)
        if not bucket_name:
            return Response(
                {"error": "S3_STORAGE_BUCKET_NAME not configured"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        s3 = S3Client()

        try:
            uploaded = s3.multipart_upload(bucket_name, file_obj)
            return Response(uploaded, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response(
                {"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
