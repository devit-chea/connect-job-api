class StorageModule:
    GENERIC = "generic"
    
class StorageClassify:
    TEMPS = "temps"
    UPLOADED = "uploaded"

    CHOICES = [
        (TEMPS, "Temp"),
        (UPLOADED, "Uploaded"),
    ]


class StorageProvider:
    LOCAL = "local"
    S3 = "s3"

    CHOICES = [
        (LOCAL, "Local"),
        (S3, "S3"),
    ]
    

class UploadStatus:
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"

    CHOICES = [
        (PENDING, "Pending"),
        (PROCESSING, "Processing"),
        (COMPLETED, "Completed"),
    ]
    
    
DEFAULT_ALLOWED_CONTENT_TYPES = {"image/png", "image/jpeg", "image/jpg", "text/plain"}
MIN_FILE_SIZE = 1024
MAX_FILE_SIZE = 10 * 1024 * 1024
