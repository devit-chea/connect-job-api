from django.urls import path

from wdg_core_file_storage.views.FileUploadView import (
    FileUploadView,
    FileMultipartUploadView,
)

urlpatterns = [
    path("upload-file", FileUploadView.as_view(), name="upload-file"),
    path(
        "multipart-upload", FileMultipartUploadView.as_view(), name="multipart-upload"
    ),
]
