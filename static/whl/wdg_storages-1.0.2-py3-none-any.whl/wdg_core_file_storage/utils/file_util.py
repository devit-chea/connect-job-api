from datetime import datetime
import os
import uuid
import httpx
import base64
import logging


logger = logging.getLogger(__name__)


def unique_file_name(filename):
    # Extract file extension
    ext = filename.split(".")[-1]
    # Generate a unique filename using UUID
    unique_name = f"{uuid.uuid4()}.{ext}"

    return unique_name


def unique_file_name_by_original(filename):
    # Extract the file name without extension and make it lowercase
    base_name = os.path.splitext(filename)[0].lower()
    # Replace spaces with underscores
    sanitized_name = base_name.replace(" ", "_")
    # Extract the file extension
    ext = filename.split(".")[-1]
    # Generate a unique filename using UUID
    unique_name = f"{sanitized_name}_{uuid.uuid4()}.{ext}"

    return unique_name

def unique_file_name_hex_by_original(filename):
    # Extract the file name without extension and make it lowercase
    base_name = os.path.splitext(filename)[0].lower()
    # Replace spaces with underscores
    sanitized_name = base_name.replace(" ", "_")
    # Extract the file extension
    ext = filename.split(".")[-1]
    # Generate a unique filename using UUID
    unique_name = f"{sanitized_name}_{uuid.uuid4().hex}.{ext}"

    return unique_name

def unique_file_name_by_original_v2(original_filename):
    """
    Generates a unique and sanitized filename based on the original filename.

    This function ensures that a file name is unique by appending a timestamp
    and a random unique ID to the sanitized base name of the original file.
    It's useful for preventing file name collisions in systems like file uploads.

    Args:
        original_filename (str): The original name of the file, including its extension.

    Returns:
        str: A unique filename string with the format:
             `sanitized_base_name_timestamp_unique_id.ext`
    """
    base, ext = os.path.splitext(original_filename)
    sanitized_name = base.replace(" ", "_")
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    unique_id = uuid.uuid4().hex[:8]

    unique_filename = f"{sanitized_name}_{timestamp}_{unique_id}{ext}"

    return unique_filename


def get_last_part(path: str):
    """
    Extracts the last part of a path after the last '/'.

    Args:
        path (str): The full path as a string.

    Returns:
        str: The last part of the path.
    """

    return path.split("/")[-1]


def get_first_path(path):
    """
    Extracts the first part of a path before the first '/'.

    Args:
        path (str): The full path as a string.

    Returns:
        str: The first part of the path.
    """

    return path.split("/")[0]


def add_slash(path):
    """
    Ensures a string ends with a '/'.

    Args:
        path (str): The input string.

    Returns:
        str: The string with a trailing '/'.
    """

    return path if path.endswith("/") else path + "/"


def split_first_path(path):
    """
    Splits the path into the first part and the rest after the first '/'.

    Args:
        path (str): The full path as a string.

    Returns:
        tuple: A tuple containing the first part and the remaining path.
    """
    parts = path.split("/", 1)
    remaining_path = parts[1] if len(parts) > 1 else ""

    return remaining_path


def format_lazy(s: str, *args, **kwargs) -> str:
    return s.format(*args, **kwargs)


def get_image_as_base64(
    url: str, mime_type: str = "image/png", data_uri: bool = False
) -> str | None:
    """
    Fetches an image from a URL and returns it as a base64-encoded string.

    Args:
        url (str): The URL of the image.
        mime_type (str, optional): MIME type for data URI. Defaults to "image/png".
        data_uri (bool, optional): If True, returns a full data URI string.

    Returns:
        str | None: The encoded base64 string, or None on error.
    """
    if not url:
        logger.debug("No URL provided for base64 conversion.")
        return None

    try:
        with httpx.Client(timeout=5.0) as client:
            response = client.get(url)

        if response.status_code == 200:
            encoded = base64.b64encode(response.content).decode("utf-8")
            return f"data:{mime_type};base64,{encoded}" if data_uri else encoded
        else:
            logger.warning(
                f"Non-200 status code {response.status_code} for image URL: {url}"
            )
            return None

    except httpx.RequestError:
        logger.exception(f"Request error while fetching image from: {url}")
        return None
    except Exception:
        logger.exception(f"Unexpected error while encoding image from: {url}")
        return None
