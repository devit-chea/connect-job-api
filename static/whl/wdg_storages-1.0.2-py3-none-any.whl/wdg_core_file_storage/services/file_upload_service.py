# wdg_core_file_storage/utils/file_manager_util.py

import uuid
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from wdg_core_file_storage.backends.s3 import S3Client
from wdg_core_file_storage.utils.file_manager_util import FileManager


class FileUploadService:
    def __init__(self, instance):
        self.instance = instance
        self.s3 = S3Client()

    def upload_files(self, files):
        """
        Upload files (single or multiple) to S3 and save metadata via FileManager.
        """
        if not files:
            return []

        bucket_name = getattr(settings, "S3_STORAGE_BUCKET_NAME", None)
        content_type = ContentType.objects.get_for_model(self.instance.__class__)
        uploaded_files_meta = []

        try:
            # Handle single or multiple uploads
            if len(files) == 1:
                upload_result = [self.s3.upload_to_s3(bucket_name, files[0])]
            else:
                upload_result = self.s3.multipart_upload_multiple(bucket_name, files)

            # Build metadata for DB
            for uploaded in upload_result:
                uploaded_files_meta.append(
                    {
                        "file_id": str(uuid.uuid4()),
                        "original_file_name": uploaded["file_name"],
                        "file_name": uploaded["file_name"],
                        "file_path": uploaded["file_key"],
                        "image_url": uploaded["url"],
                        "file_size": getattr(uploaded, "file_size", 0),
                        "file_type": getattr(
                            uploaded, "file_type", "application/octet-stream"
                        ),
                        "description": "File uploaded successfully.",
                    }
                )

            # Save metadata using your existing FileManager
            FileManager.save_files_meta_data(
                app_label="wdg_file_metadata",
                model_name="filestoragemodel",
                files_meta=uploaded_files_meta,
                ref_type=content_type.model,
                ref_id=self.instance.id,
            )

            return uploaded_files_meta

        except Exception as e:
            raise RuntimeError(f"Failed to upload files: {str(e)}")
