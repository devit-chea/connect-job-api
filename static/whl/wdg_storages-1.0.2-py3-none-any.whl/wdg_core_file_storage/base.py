from .conf import api_settings
from storages.backends.s3boto3 import S3Boto3Storage


class S3MediaStorage(S3Boto3Storage):
    default_acl = "public-read" # or "private"
    file_overwrite = False

    def __init__(self, *args, **kwargs):
        kwargs["access_key"] = api_settings.S3_ACCESS_KEY_ID
        kwargs["secret_key"] = api_settings.S3_SECRET_ACCESS_KEY
        kwargs["bucket_name"] = api_settings.S3_STORAGE_BUCKET_NAME
        kwargs["endpoint_url"] = f"https://{api_settings.S3_ENDPOINT_URL}"
        kwargs["region_name"] = None
        
        super().__init__(*args, **kwargs)

