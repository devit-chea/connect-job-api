from datetime import timedelta
from django.conf import settings
from django.test.signals import setting_changed
from rest_framework.settings import APISettings


DEFAULTS = {
    "S3_ACCESS_KEY_ID": None,
    "S3_SECRET_ACCESS_KEY": None,
    "S3_BUCKET_NAME": None,
    "S3_REGION_NAME": None,
    "S3_ENDPOINT_URL": None,
    "S3_PROTOCOL": None,
    "S3_PRESIGNED_EXPIRE": timedelta(minutes=3),
}


def collect_user_settings():
    return {
        key: getattr(settings, key, default)
        for key, default in DEFAULTS.items()
        if hasattr(settings, key)
    }


api_settings = APISettings(collect_user_settings(), DEFAULTS)


def reload_api_settings(*args, **kwargs):
    global api_settings
    if kwargs["setting"] in DEFAULTS:
        api_settings = APISettings(collect_user_settings(), DEFAULTS)


setting_changed.connect(reload_api_settings)
