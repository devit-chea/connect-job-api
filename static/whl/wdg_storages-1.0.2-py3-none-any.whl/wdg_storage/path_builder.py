import re
from datetime import datetime, timezone
from typing import Optional
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.db.models import Model

try:
    from django.db import connection
except Exception:
    connection = None


class StoragePathBuilder:
    """
    Build S3 storage object keys.

    Final:
      [_RAW]/tenant/year/content_type/filename

    Temp:
      [_RAW]/tenant/temp/year/common/filename
    """

    @staticmethod
    def build(
        *,
        filename: str,
        instance: Optional[Model] = None,
        tenant: Optional[object] = None,
        date: Optional[datetime] = None,
        is_temp: bool = False,
    ) -> str:

        date = date or datetime.now(timezone.utc)
        year = date.year

        content_type = (
            "common" if is_temp else StoragePathBuilder._get_content_type(instance)
        )

        parts = []

        raw_path = getattr(settings, "WDG_STORAGE_PATH", None)
        if raw_path:
            parts.append(raw_path.strip("/"))

        tenant_path = StoragePathBuilder._resolve_tenant_path(tenant)
        if tenant_path:
            parts.append(tenant_path)

        if is_temp:
            parts.append("temp")

        parts.extend([str(year), content_type, filename])

        return "/".join(parts)

    # -------------------------------------------------
    # CONTENT TYPE
    # -------------------------------------------------
    @staticmethod
    def _get_content_type(instance: Optional[Model]) -> str:
        if not instance:
            return "common"

        ct = ContentType.objects.get_for_model(instance.__class__)
        return ct.model

    # -------------------------------------------------
    # TENANT PATH RESOLVER
    # -------------------------------------------------
    @staticmethod
    def _resolve_tenant_path(tenant: Optional[object]) -> Optional[str]:
        """
        Resolve tenant directory safely.

        - public schema → slugified tenant.name
        - normal tenant → schema_name
        - non-tenant project → None
        """
        if not tenant:
            return None

        schema_name = getattr(tenant, "schema_name", None)
        tenant_name = getattr(tenant, "name", None)

        if not schema_name:
            return None

        # PUBLIC schema → use readable tenant name
        if schema_name == "public" and tenant_name:
            return re.sub(r"[\s]+|[^\w]", "_", tenant_name).strip("_").lower()

        return str(schema_name)
