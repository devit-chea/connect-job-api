from django.urls import include, path
from rest_framework import routers

from wdg_storage.view import BaseFileUploadView

router = routers.DefaultRouter(trailing_slash=False)
router.register(r"file-upload", BaseFileUploadView, basename="file-upload")


urlpatterns = [
    path("", include(router.urls)),
]
