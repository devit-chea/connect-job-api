import base64
import hashlib
import boto3
from django.http import Http404
from botocore.config import Config
from django.conf import settings

from django.core.exceptions import ImproperlyConfigured
from wdg_storage.constant import AccessLevelChoices, EngineChoices
from boto3.s3.transfer import TransferConfig


class S3Storage:
    """
    Stable, MinIO-safe S3 storage.
    Works behind reverse proxy.
    No chunked uploads.
    """

    def __init__(self, endpoint_url: str | None = None, presign_expire: int = 3600):
        self.presign_expire = presign_expire

        self.transfer_config = TransferConfig(
            multipart_threshold=1024 * 5, max_concurrency=10, use_threads=True  # 25MB
        )

        # Required settings
        self.access_key = getattr(settings, "AWS_S3_ACCESS_KEY_ID", None)
        self.secret_key = getattr(settings, "AWS_S3_SECRET_ACCESS_KEY", None)
        self.bucket = getattr(settings, "AWS_STORAGE_BUCKET_NAME", None)
        self.endpoint_url = endpoint_url or getattr(
            settings, "AWS_S3_ENDPOINT_URL", None
        )

        missing = []
        if not self.access_key:
            missing.append("AWS_S3_ACCESS_KEY_ID")
        if not self.secret_key:
            missing.append("AWS_S3_SECRET_ACCESS_KEY")
        if not self.bucket:
            missing.append("AWS_STORAGE_BUCKET_NAME")
        if not self.endpoint_url:
            missing.append("AWS_S3_ENDPOINT_URL")

        if missing:
            raise ImproperlyConfigured(f"Missing S3 settings: {', '.join(missing)}")

        config = Config(
            retries={"max_attempts": 3, "mode": "standard"},
            s3={"addressing_style": "path", "payload_signing_enabled": False},
            parameter_validation=True,
            request_checksum_calculation="when_required",
            response_checksum_validation="when_required",
        )

        session = boto3.Session(
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        )

        self.client = session.client(
            "s3",
            endpoint_url=self.endpoint_url,
            config=config,
        )

    # -------------------------------------------------------
    # PRESIGNED URLS
    # -------------------------------------------------------
    def presigned_get(self, key: str, expire=None):
        try:
            return self.client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket, "Key": key},
                ExpiresIn=expire or self.presign_expire,
            )
        except Exception:
            return None

    def presigned_put(self, key: str, expire=None):
        try:
            return self.client.generate_presigned_url(
                "put_object",
                Params={"Bucket": self.bucket, "Key": key},
                ExpiresIn=expire or self.presign_expire,
            )
        except Exception:
            return None

    # -------------------------------------------------------
    # WITHOUT PRESIGNED URLS
    # -------------------------------------------------------
    def get_file(self, key: str):
        """
        Directly fetch a file from the bucket.

        Returns:
            bytes: file content if successful
            None: if file not found or error occurs
        """
        try:
            response = self.client.get_object(Bucket=self.bucket, Key=key)
            return response["Body"].read()  # returns bytes
        except self.client.exceptions.NoSuchKey:
            return None
        except Exception:
            return None

    # -------------------------------------------------------
    # RAW-BYTES UPLOAD (NO CHUNKED ENCODING)
    # -------------------------------------------------------
    def upload_fileobj(
        self,
        key: str,
        mime_type: str,
        file_bytes: bytes,
        upload_engine: str = EngineChoices.DIRECTLY,
        access_level: str = AccessLevelChoices.PRIVATE,
    ):
        """
        Upload raw bytes to S3 (no chunked encoding). Optionally set ACL.

        Args:
            key (str): S3 object key
            mime_type (str): Content-Type
            file_bytes (bytes): File content
            use_presigned (bool): If True, return presigned PUT URL instead of uploading
            acl (str, optional): e.g. "public-read". Defaults to None (private object)

        Returns:
            dict: success status, key, upload_url/error
        """
        try:
            if upload_engine == EngineChoices.PRESIGNED:
                return {
                    "success": True,
                    "key": key,
                    "upload_url": self.presigned_put(key),
                }
            md5_hash = hashlib.md5(file_bytes).digest()
            content_md5 = base64.b64encode(md5_hash).decode("utf-8")
            kwargs = {
                "Bucket": self.bucket,
                "Key": key,
                "Body": file_bytes,
                "ContentType": mime_type,
                "ContentLength": len(file_bytes),
                "ACL": access_level,
                "ContentMD5": content_md5,
            }
            self.client.put_object(**kwargs)
            return {"success": True, "key": key}

        except Exception as e:
            return {"success": False, "error": str(e), "key": key}

    # -------------------------------------------------------
    # PRESIGNED URLS
    # -------------------------------------------------------

    def presigned_file_url(self, key: str):
        return self.presigned_get(key)

    # -------------------------------------------------------
    # DIRECT URLS
    # -------------------------------------------------------

    def direct_file_url(self, key: str):
        """
        Returns a direct URL to the S3 object (without presigned URL).
        The S3 object must be public for this to work.
        """
        # Check if file exists
        file_bytes = self.get_file(key)
        if not file_bytes:
            raise Http404("File not found")

        # Construct the URL
        return f"{self.endpoint_url}/{self.bucket}/{key}"  # direct S3 URL

    # -------------------------------------------------------
    # DELETE
    # -------------------------------------------------------
    def delete_file(self, key: str):
        try:
            self.client.delete_object(Bucket=self.bucket, Key=key)
            return True
        except Exception:
            return False

    def move_object(self, source_key: str, dest_key: str, copy_metadata: bool = True):
        """
        Move an object in S3 from source_key to dest_key.

        Args:
            source_key (str): Current object key in S3.
            dest_key (str): Destination key in S3.
            copy_metadata (bool): Whether to copy metadata from source to destination.

        Returns:
            bool: True if move succeeded, False otherwise.
        """
        try:
            copy_source = {"Bucket": self.bucket, "Key": source_key}

            # Copy object to new location
            self.client.copy_object(
                Bucket=self.bucket,
                Key=dest_key,
                CopySource=copy_source,
                MetadataDirective="COPY" if copy_metadata else "REPLACE",
            )

            # Delete original object
            self.client.delete_object(Bucket=self.bucket, Key=source_key)

            return True
        except Exception:
            return False
