from rest_framework import serializers

from wdg_storage.file_metadata.models.storage_model import WdgStorageModel

class FileStorageSerializer(serializers.ModelSerializer):
    class Meta:
        model = WdgStorageModel
        fields = "__all__"


class FileStorageValidateByRefSerializer(serializers.Serializer):
    ref_type = serializers.CharField()
    ref_id = serializers.IntegerField()


class FileStorageDeleteValidateSerializer(serializers.Serializer):
    id = serializers.CharField()
    file_path = serializers.CharField()


class FileStoragePreviewValidateSerializer(serializers.Serializer):
    id = serializers.CharField()
    file_id = serializers.CharField()
    file_name = serializers.CharField()


class FileStorageSaveMetaDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = WdgStorageModel
        fields = "__all__"


class FileInfoSerializer(serializers.Serializer):
    original_file_name = serializers.CharField(required=True, allow_blank=False)
    file_size = serializers.IntegerField(required=True)
    content_type = serializers.CharField(required=True)
    file_path = serializers.CharField(required=True)


class FileStorageCreateValidateSerializer(serializers.Serializer):
    file_info = serializers.ListField(child=FileInfoSerializer(), allow_empty=False)


class FileUploadSerializer(serializers.Serializer):
    file = serializers.FileField(required=False)
    files = serializers.ListField(
        child=serializers.FileField(),
        required=False,
        allow_empty=False,
    )

    def validate(self, attrs):
        file = attrs.get("file")
        files = attrs.get("files")
        # Must submit at least one
        if not file and not files:
            # Determine which key to show in error
            # Default to 'files' for multiple uploads, 'file' for single
            key = "file" if "file" in self.initial_data else "files"
            raise serializers.ValidationError(
                {
                    key: "No files were uploaded. Please select at least one file to continue."
                }
            )

        # Cannot submit both
        if file and files:
            raise serializers.ValidationError(
                "Cannot submit both 'file' and 'files' at the same time."
            )

        # If single file is used, ensure only one file
        if file and isinstance(file, list) and len(file) > 1:
            raise serializers.ValidationError(
                "Cannot select multiple files for 'file'. Use 'files' for multiple uploads."
            )

        return attrs
