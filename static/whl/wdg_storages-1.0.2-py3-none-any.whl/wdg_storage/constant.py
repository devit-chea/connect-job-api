from django.db import models
from django.utils.translation import gettext_lazy as _


class UploadStatus:
    FAILED = "failed"
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"

    CHOICES = [
        (FAILED, "Failed"),
        (PENDING, "Pending"),
        (PROCESSING, "Processing"),
        (COMPLETED, "Completed"),
    ]


class EngineChoices(models.TextChoices):
    DIRECTLY = "directly", _("Directly")
    PRESIGNED = "presigned", _("Presigned")


class ProviderChoices(models.TextChoices):
    AWS_S3 = "AWS_S3", _("AWS S3")
    AZURE_BLOB = "Azure_Blob", _("Azure Blob Storage")
    LOCAL_FILESYSTEM = "Local_Filesystem", _("Local Filesystem")
    GOOGLE_CLOUD_STORAGE = "Google_Cloud_Storage", _("Google Cloud Storage")


class AccessLevelChoices(models.TextChoices):
    """
    S3 Access Level Choices (ACLs).
    """

    PRIVATE = "private", _("Private")  # Owner only
    PUBLIC = "public-read", _("Public")  # Anyone can read
    PUBLIC_RW = "public-read-write", _(
        "Public Read/Write"
    )  # Anyone can read/write (risky)
    AUTHENTICATED = "authenticated-read", _("Authenticated")  # Authenticated AWS users
    BUCKET_OWNER_READ = "bucket-owner-read", _("Bucket Owner Read")
    BUCKET_OWNER_FULL = "bucket-owner-full-control", _("Bucket Owner Full")
    AWS_EXEC_READ = "aws-exec-read", _("AWS Exec Read")


class ResponseTypeChoices(models.TextChoices):
    FULL = "full", _("Full")
    ID_ONLY = "id_only", _("Id Only")
