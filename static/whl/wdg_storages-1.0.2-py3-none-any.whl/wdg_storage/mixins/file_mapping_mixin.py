from django.contrib.contenttypes.models import ContentType

from wdg_storage.backends.s3 import S3Client
from wdg_storage.utils.cache_utils import get_presigned_url_with_cache
from wdg_storage.file_metadata.models.storage_model import WdgStorageModel


class FileMappingMixin:

    def to_representation(self, instance):
        """
        Override to add file_path based on ref_id from the File model,
        using ContentType from serializer's Meta.model.
        """
        # Get the original serialized data
        data = super().to_representation(instance)

        try:
            # Get ContentType for the model
            content_type = ContentType.objects.get_for_model(self.Meta.model)

            # Find the related object using the instance's ID
            file = (
                WdgStorageModel.objects.filter(
                    ref_id=instance.id, ref_type=content_type.model, deleted=False
                )
                .order_by("-create_date")
                .first()
            )

            if file:
                storage_client = S3Client()
                cache_key = f"file_url:{file.file_id}"

                data["file_path"] = file.file_path
                data["image_url"] = get_presigned_url_with_cache(
                    storage_client, file.file_path, cache_key
                )
            else:
                data["file_path"] = None
                data["image_url"] = None

        except ContentType.DoesNotExist:
            data["file_path"] = None
            data["image_url"] = None

        return data
