from wdg_storage.utils.file_manager_util import FileManager
from wdg_storage.file_metadata.models.storage_model import WdgStorageModel


class FileMetaDataMixin:
    file_field_mapping = {
        "files": "default",
    }

    def perform_create(self, serializer):
        instance = super().perform_create(serializer)

        request_data = getattr(self.request, "data", {})
        self._save_file_metadata(instance, request_data)

        return instance

    def perform_update(self, serializer):
        instance = serializer.save()

        request_data = getattr(self.request, "data", {})
        self._save_file_metadata(instance, request_data)

        return instance

    def perform_destroy(self, instance):
        self._delete_file_metadata(instance)
        super().perform_destroy(instance)

    def _save_file_metadata(self, instance, request_data):
        for field_name, usage_tag in self.file_field_mapping.items():
            files = request_data.get(field_name)
            if not files:
                continue
            if not isinstance(files, list):
                files = [files]

            FileManager.save_files_meta_data(
                app_name="wdg_file_metadata",
                model_name="filestoragemodel",
                files_meta=files,
                ref_id=instance.id,
                ref_type=instance._meta.model_name,
            )

    def _delete_file_metadata(self, instance):
        WdgStorageModel.objects.filter(
            ref_id=instance.id,
            ref_type=instance._meta.model_name,
        ).delete()
