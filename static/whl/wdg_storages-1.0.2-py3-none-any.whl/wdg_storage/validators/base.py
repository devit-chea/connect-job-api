
class BaseFileValidator:
    """Base class for all file validators."""

    def __init__(self, **options):
        """Allow dynamic configuration per validator."""
        self.options = options

    def validate(self, file):
        """Perform validation on a single file. Must raise ValidationError on failure."""
        raise NotImplementedError("Subclasses must implement `validate()`.")
