from rest_framework import serializers
from .base import BaseFileValidator


class SizeValidator(BaseFileValidator):
    """Validate file size limit."""

    def _format_size(self, size_bytes):
        """Convert bytes into a human-readable format (KB, MB)."""
        if size_bytes < 1024:
            return f"{size_bytes} bytes"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.2f} KB"
        else:
            return f"{size_bytes / (1024 * 1024):.2f} MB"

    def validate(self, file):
        max_size = self.options.get("max_file_size")

        # Convert string values to int when needed
        if isinstance(max_size, str):
            try:
                max_size = int(max_size)
            except ValueError:
                raise serializers.ValidationError(
                    {"file": "max_file_size must be an integer (bytes)."}
                )

        if max_size and file.size > max_size:
            raise serializers.ValidationError(
                {
                    "file": (
                        f"File '{file.name}' exceeds the maximum size of "
                        f"{self._format_size(max_size)} "
                        f"(uploaded file size: {self._format_size(file.size)})."
                    )
                }
            )
