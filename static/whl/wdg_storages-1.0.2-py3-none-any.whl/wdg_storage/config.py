from django.conf import settings


def get_upload_config():
    """
    Retrieve the dynamic upload configuration for the wdg-storage package.

    This function centralizes configuration for file upload validation.
    Each implementing project can define settings in its `settings.py`
    to override or extend the default validation behavior.

    Returns
    -------
    dict
        A configuration dictionary containing:

        - **allowed_extensions** (`dict[str, list[str]]`):
          Dictionary of permitted file extensions grouped by file category.
          Default:
          ```python
          {
              "image": ["jpg", "jpeg", "png", "gif", "webp"],
              "document": ["pdf", "doc", "docx", "xls", "xlsx"],
              "video": ["mp4", "mov", "avi"],
              "audio": ["mp3", "wav"],
              "archive": ["zip", "rar"],
          }
          ```

        - **max_file_size** (`int`):
          Maximum file size allowed for upload, in bytes.
          Default: `5 * 1024 * 1024` (5 MiB).

        - **custom_validators** (`list[type[BaseFileValidator]]`):
          Custom validator classes extending
          `wdg_storage.validators.base.BaseFileValidator`.

    Example
    -------
    >>> from wdg_storage.utils.config import get_upload_config
    >>> config = get_upload_config()
    >>> print(config["allowed_extensions"]["image"])
    ['jpg', 'jpeg', 'png', 'gif', 'webp']

    Notes
    -----
    - You can override these settings in your project's `settings.py`:
      ```python
      WDG_STORAGE_ALLOWED_EXTENSIONS = {
          "image": ["jpg", "jpeg", "png", "webp"],
          "document": ["pdf", "docx"],
          "video": ["mp4"],
      }
      ```
    - Any missing category automatically falls back to the default.
    """

    default_allowed_extensions = {
        "image": ["jpg", "jpeg", "png", "svg", "gif", "webp"],
        "document": ["pdf", "doc", "docx", "xls", "xlsx"],
        "video": ["mp4", "mov", "avi"],
        "audio": ["mp3", "wav"],
        "archive": ["zip", "rar"],
    }

    # If settings.WDG_STORAGE_ALLOWED_EXTENSIONS = None, fallback to default
    allowed_extensions = getattr(settings, "WDG_STORAGE_ALLOWED_EXTENSIONS", None)
    if allowed_extensions is None:
        allowed_extensions = default_allowed_extensions

    return {
        "allowed_extensions": allowed_extensions,
        "max_file_size": getattr(
            settings, "WDG_STORAGE_MAX_FILE_SIZE", 5 * 1024 * 1024
        ),
        "custom_validators": getattr(settings, "WDG_STORAGE_CUSTOM_VALIDATORS", []),
    }
