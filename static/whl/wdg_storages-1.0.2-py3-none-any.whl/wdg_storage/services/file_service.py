import logging
import mimetypes
from django.conf import settings

from wdg_storage.utils.commons import compute_checksums
from wdg_storage.utils.file_util import unique_file_name, add_slash
from wdg_storage.constants import StorageClassify, StorageModule
from wdg_storage.file_metadata.models.storage_model import WdgStorageModel

from wdg_storage.backends.s3 import S3Client

logger = logging.getLogger(__name__)


class FileStorageService:
    """
    Service to handle file uploads, metadata extraction, and saving to storage.
    """

    @staticmethod
    def save_file(files, storage_provider="AWS_S3"):
        """
        Save one or multiple files to WdgStorageModel and S3, populate metadata.
        Returns a list of file_ids for saved files.
        """
        s3 = S3Client()

        bucket_name = getattr(settings, "S3_BUCKET_NAME", None)
        if not bucket_name:
            logger.error("S3_BUCKET_NAME is missing in settings. Cannot save files.")
            raise ValueError(
                "File upload is temporarily unavailable. Please try again later."
            )

        if not files:
            raise ValueError(
                "No files were uploaded. Please select at least one file to continue."
            )

        saved_instances = []

        for file in files:
            file_bytes = file.read()
            file_size_bytes = file.size
            original_filename = file.name
            stored_filename = unique_file_name(original_filename)
            sha256_checksum, _ = compute_checksums(file)
            module = StorageClassify.TEMPS
            classify = StorageModule.GENERIC
            storage_path = f"{add_slash(classify)}{add_slash(module)}{stored_filename}"
            mime_type = (
                file.content_type
                or mimetypes.guess_type(original_filename)[0]
                or "application/octet-stream"
            )

            # Upload to S3
            s3.put_object_to_s3(bucket_name, storage_path, mime_type, file_bytes)
            # Save metadata to DB
            instance = WdgStorageModel.objects.create(
                original_filename=original_filename,
                stored_filename=stored_filename,
                mime_type=mime_type,
                file_size_bytes=file_size_bytes,
                checksum=sha256_checksum,
                storage_path=storage_path,
                storage_provider=storage_provider,
                image_url=storage_path,
            )
            saved_instances.append(instance)

        # Return all file_ids
        return [instance.file_id for instance in saved_instances]

    @staticmethod
    def update_file(file_id, new_file=None, ref_id=None, ref_type=None, write_uid=None):
        """
        Update metadata or replace an existing file in S3.
        """
        from wdg_storage.file_metadata.models.storage_model import WdgStorageModel

        file_record = WdgStorageModel.objects.filter(file_id=file_id).first()
        if not file_record:
            raise ValueError("File not found.")

        # If a new file is provided, upload and replace
        if new_file:
            s3_client = S3Client()
            new_s3_key = s3_client.upload(new_file)
            file_record.file_name = new_file.name
            file_record.file_path = new_s3_key

        # Update metadata
        if ref_id:
            file_record.ref_id = ref_id
        if ref_type:
            file_record.ref_type = ref_type
        if write_uid:
            file_record.write_uid = write_uid

        file_record.save()
        return {"id": file_record.id, "file_name": file_record.file_name}

    @staticmethod
    def delete_file(file_id):
        """
        Delete file from S3 and remove metadata record.
        """
        from wdg_storage.file_metadata.models.storage_model import WdgStorageModel

        file_record = WdgStorageModel.objects.filter(file_id=file_id).first()
        if not file_record:
            raise ValueError("File not found.")

        s3_client = S3Client()

        # Delete from S3
        if file_record.file_path:
            s3_client.delete(file_record.file_path)

        # Delete metadata
        file_record.delete()
