import re
import logging
import mimetypes
from typing import List, Optional
from django.conf import settings
from django.db.models import Model, QuerySet
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ImproperlyConfigured
from botocore.exceptions import ClientError

from wdg_storage.constants import UploadStatus
from wdg_storage.file_metadata.models.storage_model import WdgStorageModel
from wdg_storage.utils.commons import compute_checksums
from wdg_storage.utils.file_util import unique_file_name, add_slash
from wdg_storage.backends.s3_client import S3Storage

logger = logging.getLogger(__name__)

# --------------------------------------------------------
# CONSTANTS
# --------------------------------------------------------
NO_FILES_FOUND = "No files found."
_RAW_S3_BUCKET_PATH = getattr(settings, "WDG_STORAGE_PATH", None)
_AWS_S3_PRESIGN_EXPIRE = getattr(settings, "AWS_S3_PRESIGN_EXPIRE", 3600)
_WDG_STORAGE_PROXY_URL = getattr(settings, "WDG_STORAGE_PROXY_URL", None)


class FileStorageService:
    """
    File storage service using S3Storage (MinIO/AWS compatible).
    Errors are raised on failure (Option 2).
    """

    # -------------------------
    # Internal helpers
    # -------------------------
    @staticmethod
    def _sanitize_s3_path(value: str) -> str:
        if not value or not isinstance(value, str):
            raise ImproperlyConfigured(
                "Environment variable WDG_STORAGE_PATH must be a non-empty string."
            )
        value = value.replace("\\", "/")
        value = value.lstrip("/")
        value = re.sub(r"/+", "/", value)
        if not value.endswith("/"):
            value += "/"
        return value

    @staticmethod
    def _ensure_list(value):
        if not value:
            return []
        if isinstance(value, list):
            return value
        return [value]

    @staticmethod
    def _extract_ref_from_instance(instance: Model):
        if not isinstance(instance, Model):
            return None, None
        content_type = ContentType.objects.get_for_model(instance.__class__)
        return content_type.model, instance.pk

    @staticmethod
    def _apply_reference(instance: Model, f: WdgStorageModel):
        if not isinstance(instance, Model):
            return
        ref_type, ref_id = FileStorageService._extract_ref_from_instance(instance)
        f.ref_type = ref_type
        f.ref_id = ref_id

        if hasattr(instance, "write_uid"):
            f.write_uid = instance.write_uid
        if hasattr(instance, "create_uid"):
            f.create_uid = instance.create_uid

    @staticmethod
    def _key(stored_name: str) -> str:
        base = add_slash(FileStorageService._sanitize_s3_path(_RAW_S3_BUCKET_PATH))
        return f"{base}{stored_name}"

    @staticmethod
    def _extract_file_bytes(uploaded) -> bytes:
        """
        Accept either raw bytes or a file-like object (Django UploadedFile).
        """
        if hasattr(uploaded, "read"):
            # ensure pointer at start (defensive)
            try:
                uploaded.seek(0)
            except Exception:
                pass
            content = uploaded.read()
            # rewind if possible for caller's later use
            try:
                uploaded.seek(0)
            except Exception:
                pass
            return content
        return uploaded

    @staticmethod
    def _extract_file_metadata(uploaded, content: bytes):
        size = getattr(uploaded, "size", len(content))
        name = getattr(uploaded, "name", "unnamed_file")
        mime = (
            getattr(uploaded, "content_type", None)
            or mimetypes.guess_type(name)[0]
            or "application/octet-stream"
        )
        return size, name, mime

    @staticmethod
    def _bucket_name():
        bucket = getattr(settings, "AWS_STORAGE_BUCKET_NAME", None)
        if not bucket:
            raise ImproperlyConfigured("S3 bucket missing.")
        return bucket

    @staticmethod
    def _query_by_instance_or_id(instance=None, file_id=None) -> QuerySet:
        if instance:
            ref_type, ref_id = FileStorageService._extract_ref_from_instance(instance)
            return WdgStorageModel.objects.by_reference(ref_id, ref_type)
        ids = FileStorageService._ensure_list(file_id)
        return WdgStorageModel.objects.filter(pk__in=ids)

    # -------------------------
    # Save / Upload
    # -------------------------
    @staticmethod
    def save_file(
        files, instance: Optional[Model] = None, storage_provider="AWS_S3"
    ) -> List[str]:
        """
        Upload one or many files. Returns list of created file_ids.
        Raises RuntimeError on any upload failure.
        """
        saved_ids: List[str] = []
        s3_engine = S3Storage(
            endpoint_url=_WDG_STORAGE_PROXY_URL, presign_expire=_AWS_S3_PRESIGN_EXPIRE
        )

        for uploaded in FileStorageService._ensure_list(files):
            # read bytes (this returns bytes for both bytes and UploadedFile)
            file_bytes = FileStorageService._extract_file_bytes(uploaded)

            size, original_name, mime = FileStorageService._extract_file_metadata(
                uploaded, file_bytes
            )
            stored_name = unique_file_name(original_name)
            sha256, md5 = compute_checksums(file_bytes)
            key = FileStorageService._key(stored_name)

            # upload raw bytes (raise on failure)
            result = s3_engine.upload_fileobj(
                key=key, mime_type=mime, file_bytes=file_bytes
            )
            if not result.get("success"):
                err = result.get("error") or "Unknown upload error"
                logger.error("S3 upload failed for key=%s: %s", key, err)
                raise RuntimeError(f"S3 upload failed for {key}: {err}")

            # create DB record
            obj = WdgStorageModel.objects.create(
                original_filename=original_name,
                stored_filename=stored_name,
                mime_type=mime,
                file_size_bytes=size,
                checksum=sha256,
                storage_path=key,
                storage_provider=storage_provider,
                status=UploadStatus.PENDING,
            )

            FileStorageService._apply_reference(instance, obj)
            obj.save()

            saved_ids.append(obj.file_id)

        return saved_ids

    # -------------------------
    # Update
    # -------------------------
    @staticmethod
    def update_file(file_id=None, new_file=None, instance=None, is_success=True):
        if not file_id:
            raise ValueError("file_id required.")

        if new_file is None:
            FileStorageService._update_metadata_only(file_id, instance, is_success)
            return FileStorageService._ensure_list(file_id)

        return FileStorageService._replace_files(
            file_id, new_file, instance, is_success
        )

    @staticmethod
    def _update_metadata_only(file_id, instance, is_success):
        qs = FileStorageService._query_by_instance_or_id(file_id=file_id)
        for f in qs:
            f.status = UploadStatus.COMPLETED if is_success else UploadStatus.FAILED
            FileStorageService._apply_reference(instance, f)
            f.save()

    @staticmethod
    def _replace_files(file_id, new_file, instance, is_success):
        s3_engine = S3Storage(
            endpoint_url=_WDG_STORAGE_PROXY_URL, presign_expire=_AWS_S3_PRESIGN_EXPIRE
        )
        updated_ids: List[str] = []

        file_ids = FileStorageService._ensure_list(file_id)
        new_files = FileStorageService._ensure_list(new_file)

        for idx, fid in enumerate(file_ids):
            f = WdgStorageModel.objects.filter(file_id=fid).first()
            if not f:
                raise ValueError(f"File with id {fid} not found.")

            uploaded = new_files[idx]
            file_bytes = FileStorageService._extract_file_bytes(uploaded)
            size, original_name, mime = FileStorageService._extract_file_metadata(
                uploaded, file_bytes
            )

            stored_name = unique_file_name(original_name)
            sha256, md5 = compute_checksums(file_bytes)
            key = FileStorageService._key(stored_name)

            result = s3_engine.upload_fileobj(
                key=key, mime_type=mime, file_bytes=file_bytes
            )
            if not result.get("success"):
                err = result.get("error") or "Unknown upload error"
                logger.error("S3 upload failed for key=%s: %s", key, err)
                raise RuntimeError(f"S3 upload failed for {key}: {err}")

            f.original_filename = original_name
            f.stored_filename = stored_name
            f.mime_type = mime
            f.file_size_bytes = size
            f.storage_path = key
            f.checksum = sha256
            f.status = UploadStatus.COMPLETED if is_success else UploadStatus.FAILED

            FileStorageService._apply_reference(instance, f)
            f.save()

            updated_ids.append(f.file_id)

        return updated_ids

    # -------------------------
    # Read (presigned URL only)
    # -------------------------
    @staticmethod
    def read_file(instance=None, file_id=None):
        qs = FileStorageService._query_by_instance_or_id(instance, file_id)
        files = list(qs)
        if not files:
            raise ValueError(NO_FILES_FOUND)

        s3_engine = S3Storage(
            endpoint_url=_WDG_STORAGE_PROXY_URL, presign_expire=_AWS_S3_PRESIGN_EXPIRE
        )
        results = []
        for f in files:
            url = s3_engine.get_file_url(f.storage_path)
            if not url:
                logger.error("Failed to generate presigned URL for %s", f.storage_path)
                raise RuntimeError(
                    f"Failed to generate presigned URL for {f.storage_path}"
                )
            results.append(
                {
                    "file_id": f.file_id,
                    "filename": f.original_filename,
                    "mime_type": f.mime_type,
                    "size": f.file_size_bytes,
                    "url": url,
                }
            )
        return results

    # -------------------------
    # Delete / Restore
    # -------------------------
    @staticmethod
    def delete_files(instance=None, file_id=None, soft=False):
        qs = FileStorageService._query_by_instance_or_id(instance, file_id)
        files = list(qs)
        if not files:
            return 0

        if soft:
            return FileStorageService._soft_delete(files, instance)
        return FileStorageService._hard_delete(files)

    @staticmethod
    def _soft_delete(files, instance):
        count = 0
        for f in files:
            f.deleted = True
            f.status = UploadStatus.FAILED
            FileStorageService._apply_reference(instance, f)
            f.save(update_fields=["deleted", "status", "write_uid", "write_date"])
            count += 1
        return count

    @staticmethod
    def _hard_delete(files):
        count = 0
        s3_engine = S3Storage(
            endpoint_url=_WDG_STORAGE_PROXY_URL, presign_expire=_AWS_S3_PRESIGN_EXPIRE
        )

        for f in files:
            key = f.storage_path
            try:
                ok = s3_engine.delete_file(key)
                if not ok:
                    raise RuntimeError(f"Failed to delete S3 object {key}")
            except ClientError as e:
                logger.exception("Failed to delete S3 object %s: %s", key, e)
                raise
            except Exception as e:
                logger.exception("Unexpected error deleting S3 object %s: %s", key, e)
                raise

            try:
                f.delete()
                count += 1
            except Exception as e:
                logger.exception(
                    "Failed to delete DB record (file_id=%s): %s", f.file_id, e
                )
                raise

        return count

    @staticmethod
    def restore_files(instance=None, file_id=None):
        qs = FileStorageService._query_by_instance_or_id(instance, file_id).filter(
            deleted=True
        )
        files = list(qs)
        if not files:
            return 0

        count = 0
        for f in files:
            f.deleted = False
            f.status = UploadStatus.COMPLETED
            FileStorageService._apply_reference(instance, f)
            f.save()
            count += 1

        return count

    # -------------------------
    # Download (presigned)
    # -------------------------
    @staticmethod
    def get_download_url(file_id=None, instance=None):
        qs = FileStorageService._query_by_instance_or_id(instance, file_id).filter(
            deleted=False
        )
        files = list(qs)
        if not files:
            raise ValueError(NO_FILES_FOUND)

        s3_engine = S3Storage(
            endpoint_url=_WDG_STORAGE_PROXY_URL, presign_expire=_AWS_S3_PRESIGN_EXPIRE
        )
        results = []
        for f in files:
            url = s3_engine.download_file(f.storage_path)
            if not url:
                logger.error(
                    "Failed to generate presigned download URL for %s", f.storage_path
                )
                raise RuntimeError(
                    f"Failed to generate presigned download URL for {f.storage_path}"
                )
            results.append(
                {
                    "file_id": f.file_id,
                    "filename": f.original_filename,
                    "url": url,
                }
            )
        return results
