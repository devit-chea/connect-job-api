from wdg_storage.file_metadata.models.storage_model import WdgStorageModel


@staticmethod
def get_files_by_id(id):
    try:
        return WdgStorageModel.objects.filter(id=id).first()
    except WdgStorageModel.DoesNotExist:
        return None


@staticmethod
def get_files_by_file_id(file_id):
    try:
        return WdgStorageModel.objects.filter(file_id=file_id).first()
    except WdgStorageModel.DoesNotExist:
        return None


@staticmethod
def get_files_by_ref_type_and_file_ids(ref_type, file_id: list):
    try:
        return (
            WdgStorageModel.objects.order_by("-id")
            .filter(file_id__in=file_id, ref_type=ref_type)
            .get()
        )
    except WdgStorageModel.DoesNotExist:
        return None


@staticmethod
def get_files_by_ref_type_and_ids(ref_type, ref_id: list):
    try:
        return (
            WdgStorageModel.objects.order_by("-id")
            .filter(ref_id__in=ref_id, ref_type=ref_type)
            .get()
        )
    except WdgStorageModel.DoesNotExist:
        return None
