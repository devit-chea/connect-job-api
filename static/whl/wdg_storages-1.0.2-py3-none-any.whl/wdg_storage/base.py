import uuid
from typing import Union, List
from wdg_storage.service import FileStorageService, update_file_record


def _normalize_file_inputs(
    files_data=None,
    file_id: Union[str, uuid.UUID, List[Union[str, uuid.UUID]]] = None,
    instance=None,
):
    """
    Normalize all input types into a standard list of:
        [{"file_id": <str>, "instance": <Model or None>}]

    Supported input formats:
        1. files_data = [{"file_id": "A123", "instance": obj}, ...]
        2. file_id = "A123" or UUID
        3. file_id = ["A123", "B456"] or [UUID, ...]
        4. instance = some_model_instance
        5. file_id + instance together
    """

    normalized = []

    # 1. If files_data provided
    if files_data is not None:
        if isinstance(files_data, dict):
            files_data = [files_data]

        if isinstance(files_data, list):
            for item in files_data:
                normalized.append(
                    {
                        "file_id": (
                            str(item.get("file_id")) if item.get("file_id") else None
                        ),
                        "instance": item.get("instance"),
                    }
                )
            return normalized

    # Helper to convert file_id to string if UUID
    def _to_str(fid):
        return str(fid) if isinstance(fid, uuid.UUID) else fid

    # 2. Single file_id
    if isinstance(file_id, (str, uuid.UUID)):
        normalized.append({"file_id": _to_str(file_id), "instance": instance})
        return normalized

    # 3. Multiple file_ids
    if isinstance(file_id, list):
        for fid in file_id:
            if not isinstance(fid, (str, uuid.UUID)):
                raise ValueError(f"Invalid file_id type: {type(fid)}")
            normalized.append({"file_id": _to_str(fid), "instance": instance})
        return normalized

    # 4. Instance only (get all files for instance)
    if instance is not None:
        normalized.append({"file_id": None, "instance": instance})
        return normalized

    raise ValueError("You must provide files_data, file_id, or instance.")


# =====================================================
# 1. SERVICE CLASS VERSION WITH FULL DOCUMENTATION
# =====================================================
class WdgStorageService:
    """
    WdgStorageService
    =================

    Helper class for interacting with the file storage system.
    Provides 3 main features:

        - update_metadata()    → update status (success/failed)
        - get_files()       → get file metadata + presigned URL
        - download_files()  → get presigned URL only

    ----------------------------------------------------------------------
    SUPPORTED USAGE PATTERNS
    ----------------------------------------------------------------------

    You may call the service with any of the following combinations:

    1. Using files_data (explicit format)
       Example:
           WdgStorageService.get_files([
               {"file_id": "A123", "instance": order},
               {"file_id": "B456", "instance": order},
           ])

       Structure:
           [
               {
                   "file_id": <str>,      # optional
                   "instance": <Model>,   # optional
               }
           ]

    2. Using a single file_id
           WdgStorageService.get_files(file_id="A123")

    3. Using a list of file_ids
           WdgStorageService.get_files(file_id=["A123", "B456"])

    4. Using only instance (returns all files referenced by the instance)
           WdgStorageService.get_files(instance=invoice)

    5. Using file_id + instance together
           WdgStorageService.get_files(file_id="A123", instance=order)

    6. Function versions (shortcut functions)
           get_files("A123")
           download_files(["A123", "B456"])
           update_metadata(file_id="A123", is_success=True)

    7. Mixin usage inside serializer or view
           class MySerializer(WdgStorageMixin, serializers.Serializer):
               def validate(self, data):
                   files = self.get_files(file_id=data["file_id"])
                   return data

    ----------------------------------------------------------------------
    RETURN FORMATS
    ----------------------------------------------------------------------

    get_files():
        Returns metadata + URL:
            [
                {
                    "file_id": "A123",
                    "filename": "...",
                    "mime_type": "...",
                    "size": 12345,
                    "deleted": false,
                    "url": "https://presigned-url..."
                }
            ]

    download_files():
        Returns only presigned URLs:
            [
                {
                    "file_id": "A123",
                    "url": "https://presigned-url..."
                }
            ]

    update_metadata():
        Returns:
            int → number of updated records
    """

    # Update files
    @staticmethod
    def update_metadata(files_data=None, file_id=None, instance=None, is_success=True):
        normalized = _normalize_file_inputs(files_data, file_id, instance)

        updated = 0
        for item in normalized:
            updated += update_file_record(
                file_id=item["file_id"],
                instance=item["instance"],
                is_success=is_success,
            )
        return updated

    # Get file metadata and (presigned True/False)
    @staticmethod
    def get_files(files_data=None, file_id=None, instance=None, presigned=True):
        normalized = _normalize_file_inputs(files_data, file_id, instance)

        results = []
        for item in normalized:
            file_info = FileStorageService.download_file_url(
                file_id=item["file_id"],
                instance=item["instance"],
                presigned=presigned,
            )
            results.extend(file_info)
        return results

    # Download file and (presigned True/False)
    @staticmethod
    def download_files(files_data=None, file_id=None, instance=None, presigned=True):
        normalized = _normalize_file_inputs(files_data, file_id, instance)

        urls = []
        for item in normalized:
            file_info = FileStorageService.download_file_url(
                file_id=item["file_id"],
                instance=item["instance"],
                presigned=presigned,
            )
            urls.append(file_info)
        return urls

    # GET file and (presigned True/False)
    @staticmethod
    def get_file_url(files_data=None, file_id=None, instance=None, presigned=True):
        """
        Get a single presigned URL for a file.

        Returns the URL of the first file found, or None if not found.
        """
        normalized = _normalize_file_inputs(files_data, file_id, instance)

        if not normalized:
            return None

        first_item = normalized[0]
        file_info = FileStorageService.download_file_url(
            file_id=first_item["file_id"],
            instance=first_item["instance"],
            presigned=presigned,
        )

        if not file_info:
            return None

        return file_info[0]["url"]

    # Delete file and (soft True/False)
    @staticmethod
    def delete_files(instance=None, file_id=None, soft=False) -> str:

        deleted_count = FileStorageService.delete(instance, file_id, soft)
        return (
            "No files were deleted."
            if deleted_count == 0
            else (
                "1 file deleted successfully."
                if deleted_count == 1
                else f"{deleted_count} files deleted successfully."
            )
        )

    # Restore files
    @staticmethod
    def restore_files(instance=None, file_id=None) -> str:
        restore_count = FileStorageService.restore(instance, file_id)
        return (
            "No files were restored."
            if restore_count == 0
            else (
                "1 file restored successfully."
                if restore_count == 1
                else f"{restore_count} files restored successfully."
            )
        )


# =====================================================
# 2. MIXIN VERSION
# =====================================================
class WdgStorageMixin:

    def update_metadata(self, *args, **kwargs):
        return WdgStorageService.update_metadata(*args, **kwargs)

    def get_files(self, *args, **kwargs):
        return WdgStorageService.get_files(*args, **kwargs)

    def download_files(self, *args, **kwargs):
        return WdgStorageService.download_files(*args, **kwargs)

    def get_file_url(self, *args, **kwargs):
        return WdgStorageService.get_file_url(*args, **kwargs)

    def delete_files(self, *args, **kwargs):
        return WdgStorageService.delete_files(*args, **kwargs)

    def restore_files(self, *args, **kwargs):
        return WdgStorageService.restore_files(*args, **kwargs)


# =====================================================
# 3. FUNCTION VERSION
# =====================================================
def update_metadata(*args, **kwargs):
    return WdgStorageService.update_metadata(*args, **kwargs)


def get_files(*args, **kwargs):
    return WdgStorageService.get_files(*args, **kwargs)


def download_files(*args, **kwargs):
    return WdgStorageService.download_files(*args, **kwargs)


def get_file_url(*args, **kwargs):
    return WdgStorageService.get_file_url(*args, **kwargs)


def delete_files(*args, **kwargs):
    return WdgStorageService.delete_files(*args, **kwargs)


def restore_files(*args, **kwargs):
    return WdgStorageService.restore_files(*args, **kwargs)
