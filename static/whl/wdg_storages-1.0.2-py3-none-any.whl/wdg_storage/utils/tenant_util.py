from typing import Optional


def get_tenant() -> Optional[object]:
    """
    Safely return current tenant instance if django-tenants is enabled.
    Returns None when:
      - django-tenants is not installed
      - connection has no schema_name
      - tenant cannot be resolved
    """
    try:
        from django.db import connection
        from django_tenants.utils import get_tenant_model

        schema_name = getattr(connection, "schema_name", None)
        if not schema_name:
            return None

        TenantModel = get_tenant_model()
        return TenantModel.objects.filter(schema_name=schema_name).first()

    except Exception:
        return None


def get_tenant_domain() -> Optional[str]:
    """
    Safely return primary domain of tenant.
    Returns None if tenants are not used or domain not found.
    """
    try:
        tenant = get_tenant()
        if not tenant:
            return None

        # django-tenants API
        if hasattr(tenant, "get_primary_domain"):
            domain = tenant.get_primary_domain()
            return getattr(domain, "domain", None)

        return None

    except Exception:
        return None
