import logging
import time
from urllib.parse import parse_qs, urlparse

from django.core.cache import caches
from django.core.cache.backends.base import InvalidCacheBackendError
from wdg_storage.backends.s3 import S3Client

logger = logging.getLogger(__name__)

PRIMARY_ALIAS = "default"  # Redis
FALLBACK_ALIAS = "locmem"  # Local memory


def _get_cache(alias: str):
    try:
        return caches[alias]
    except InvalidCacheBackendError:
        logger.warning(
            f"Cache alias '{alias}' not found, falling back to {FALLBACK_ALIAS}"
        )
        return caches[FALLBACK_ALIAS]


def cache_get(key: str):
    try:
        return _get_cache(PRIMARY_ALIAS).get(key)
    except Exception as e:
        logger.error(f"Redis cache GET failed: {e}. Falling back to LocMem.")
        return _get_cache(FALLBACK_ALIAS).get(key)


def cache_set(key: str, value, timeout: int = None):
    try:
        return _get_cache(PRIMARY_ALIAS).set(key, value, timeout)
    except Exception as e:
        logger.error(f"Redis cache SET failed: {e}. Falling back to LocMem.")
        return _get_cache(FALLBACK_ALIAS).set(key, value, timeout)


def cache_delete(key: str):
    try:
        return _get_cache(PRIMARY_ALIAS).delete(key)
    except Exception as e:
        logger.error(f"Redis cache DELETE failed: {e}. Falling back to LocMem.")
        return _get_cache(FALLBACK_ALIAS).delete(key)


def cache_invalidate_presigned(bucket: str, key: str):
    """
    Invalidate presigned URLs when an S3 object is deleted.
    """
    download_cache_key = f"presign:download:{bucket}:{key}"
    upload_cache_key = f"presign:upload:{bucket}:{key}"

    cache_delete(download_cache_key)
    cache_delete(upload_cache_key)

    logger.info(f"Invalidated presigned cache for {bucket}/{key}")


def get_presigned_url_with_cache(storage_client, file_path: str, cache_key: str):
    """Generate or return cached presigned URL for a file."""

    cached_url = cache_get(cache_key)
    if cached_url:
        return cached_url
    
    # generate new URL
    signed_url = storage_client.generate_download_presigned_url(file_path, expiry=300)

    # extract expiry
    parsed_url = urlparse(signed_url)
    query_params = parse_qs(parsed_url.query)
    expires = int(query_params.get("Expires", [0])[0])

    # calculate TTL
    ttl = expires - int(time.time())
    if ttl > 0:
        cache_set(cache_key, signed_url, timeout=ttl)

    return signed_url
