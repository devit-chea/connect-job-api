from django.conf import settings
from rest_framework.response import Response
from rest_framework import viewsets, status
from rest_framework.decorators import action
from django.utils.module_loading import import_string

from wdg_storage.utils.config import get_upload_config
from wdg_storage.serializers import BaseFileUploadSerializer
from wdg_storage.services.storage_service import FileStorageService
from wdg_storage.file_metadata.models.storage_model import WdgStorageModel
from wdg_storage.constants import UploadStatus


filter_backends = [
    import_string(f) for f in getattr(settings, "FILE_UPLOAD_FILTER_BACKENDS", [])
]


class BaseFileUploadView(viewsets.ViewSet):
    """
    Full CRUD file upload system using FileStorageService.
    Supports:
      - upload (POST)
      - replace/update (PUT)
      - partial update (PATCH) for soft delete / restore
      - delete (DELETE)
      - list (GET)
      - retrieve (GET/<id>/)
    """

    filter_backends = filter_backends

    # --------------------------------------------------------
    # SERIALIZER LOADING
    # --------------------------------------------------------
    def get_serializer(self, *args, **kwargs):
        config = get_upload_config()
        return BaseFileUploadSerializer(
            *args,
            allowed_extensions=config["allowed_extensions"],
            max_file_size=config["max_file_size"],
            **kwargs,
        )

    # --------------------------------------------------------
    # LIST ALL FILES (GET)
    # --------------------------------------------------------
    def list(self, request, *args, **kwargs):
        ref_id = request.query_params.get("ref_id")
        ref_type = request.query_params.get("ref_type")

        qs = WdgStorageModel.objects.all()

        if ref_id and ref_type:
            qs = qs.by_reference(ref_id, ref_type)

        data = [
            {
                "file_id": f.file_id,
                "original_filename": f.original_filename,
                "stored_filename": f.stored_filename,
                "mime_type": f.mime_type,
                "size": f.file_size_bytes,
                "deleted": f.deleted,
                "status": f.status,
                "url": FileStorageService.get_download_url(file_id=f.file_id)[0]["url"],
            }
            for f in qs
        ]

        return Response(data, status=status.HTTP_200_OK)

    # --------------------------------------------------------
    # RETRIEVE SINGLE FILE (GET /<id>/)
    # --------------------------------------------------------
    def retrieve(self, request, pk=None, *args, **kwargs):
        urls = FileStorageService.get_download_url(file_id=pk)
        return Response(urls[0], status=status.HTTP_200_OK)

    # --------------------------------------------------------
    # UPLOAD (POST)
    # --------------------------------------------------------
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        files = serializer.validated_data["file"]
        if not isinstance(files, (list, tuple)):
            files = [files]

        file_ids = FileStorageService.save_file(files)
        return Response({"file": file_ids}, status=status.HTTP_201_CREATED)

    # --------------------------------------------------------
    # UPDATE/REPLACE FILE (PUT /<id>/)
    # --------------------------------------------------------
    def update(self, request, pk=None, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        files = serializer.validated_data.get("file")
        updated_ids = FileStorageService.update_file(file_id=pk, new_file=files)

        return Response({"file": updated_ids}, status=status.HTTP_200_OK)

    # --------------------------------------------------------
    # PARTIAL UPDATE (PATCH) — SOFT DELETE / RESTORE
    # --------------------------------------------------------
    @action(detail=True, methods=["patch"])
    def soft_delete(self, request, pk=None, *args, **kwargs):
        """
        PATCH /files/<id>/soft_delete/ { "deleted": true }
        """
        deleted = request.data.get("deleted")

        if deleted is True:
            FileStorageService.delete_files(file_id=pk, soft=True)
            return Response(
                {"message": f"File {pk} soft-deleted."},
                status=status.HTTP_200_OK,
            )
        elif deleted is False:
            FileStorageService.restore_files(file_id=pk)
            return Response(
                {"message": f"File {pk} restored."},
                status=status.HTTP_200_OK,
            )
        else:
            return Response(
                {"error": "Invalid value for 'deleted'. Use true or false."},
                status=status.HTTP_400_BAD_REQUEST,
            )

    # --------------------------------------------------------
    # HARD DELETE (DELETE /<id>/)
    # --------------------------------------------------------
    def destroy(self, request, pk=None, *args, **kwargs):
        FileStorageService.delete_files(file_id=pk, soft=False)
        return Response(
            {"message": f"File {pk} deleted successfully."},
            status=status.HTTP_204_NO_CONTENT,
        )
