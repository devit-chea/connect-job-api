from rest_framework import viewsets

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.conf import settings
from django.utils.module_loading import import_string
from wdg_storage.backends.s3 import S3Client

from wdg_storage.services.file_service import FileStorageService
from wdg_storage.serializers.file_storage_serializer import FileUploadSerializer

# Dynamically import filters from settings
filter_backends = [
    import_string(f) for f in getattr(settings, "FILE_UPLOAD_FILTER_BACKENDS", [])
]


class FileUploadView(viewsets.ViewSet):
    """
    Upload single or multiple files to S3 using serializer validation.
    """

    filter_backends = filter_backends

    def create(self, request, *args, **kwargs):
        """
        Upload one or multiple files to S3 using serializer validation.
        """
        serializer = FileUploadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        validated_data = serializer.validated_data

        if "file" in validated_data:
            files = [validated_data["file"]]
            response_key = "file"
            single_file_upload = True
        else:
            files = validated_data["files"]
            response_key = "files"
            single_file_upload = False

        try:
            uploaded_file_ids = FileStorageService.save_file(files)

            # Single file: return string, not list
            if single_file_upload:
                return Response(
                    {response_key: uploaded_file_ids[0]},
                    status=status.HTTP_201_CREATED,
                )
            else:
                return Response(
                    {response_key: uploaded_file_ids},
                    status=status.HTTP_201_CREATED,
                )

        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            return Response(
                {"error": "File upload failed. Please try again later."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def update(self, request, pk=None, *args, **kwargs):
        """
        Update a file record or replace the actual file in S3.
        - `pk`: file ID to update.
        - Supports updating metadata or replacing the file.
        """
        new_file = request.FILES.get("file")
        ref_id = request.data.get("ref_id")
        ref_type = request.data.get("ref_type")
        write_uid = request.data.get("write_uid")

        try:
            updated_file = FileStorageService.update_file(
                file_id=pk,
                new_file=new_file,
                ref_id=ref_id,
                ref_type=ref_type,
                write_uid=write_uid,
            )
            return Response(updated_file, status=status.HTTP_200_OK)
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response(
                {"error": "File update failed. Please try again later."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def destroy(self, request, pk=None, *args, **kwargs):
        """
        Delete a file from S3 and remove its metadata record.
        - `pk`: file ID to delete.
        """
        try:
            FileStorageService.delete_file(file_id=pk)
            return Response(
                {"message": f"File {pk} deleted successfully."},
                status=status.HTTP_204_NO_CONTENT,
            )
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_404_NOT_FOUND)
        except Exception:
            return Response(
                {"error": "File deletion failed. Please try again later."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class FileMultipartUploadView(APIView):
    """
    Upload a large file using multipart upload.
    """

    def post(self, request, *args, **kwargs):
        file_obj = request.FILES.get("file")
        if not file_obj:
            return Response(
                {"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST
            )

        bucket_name = getattr(settings, "S3_BUCKET_NAME", None)
        if not bucket_name:
            return Response(
                {"error": "S3_BUCKET_NAME not configured"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        s3 = S3Client()

        try:
            uploaded = s3.multipart_upload(bucket_name, file_obj)
            return Response(uploaded, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response(
                {"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
