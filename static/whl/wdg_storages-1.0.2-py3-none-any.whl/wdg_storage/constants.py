from django.db import models
from django.utils.translation import gettext_lazy as _


class UploadStatus:
    FAILED = "failed"
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"

    CHOICES = [
        (FAILED, "Failed"),
        (PENDING, "Pending"),
        (PROCESSING, "Processing"),
        (COMPLETED, "Completed"),
    ]


class ProviderChoices(models.TextChoices):
    AWS_S3 = "AWS_S3", _("AWS S3")
    AZURE_BLOB = "Azure_Blob", _("Azure Blob Storage")
    LOCAL_FILESYSTEM = "Local_Filesystem", _("Local Filesystem")
    GOOGLE_CLOUD_STORAGE = "Google_Cloud_Storage", _("Google Cloud Storage")


class AccessLevelChoices(models.TextChoices):
    PUBLIC = "public", _("Public")
    PRIVATE = "private", _("Private")
